# FitBody AI

## Current State
A fresh Caffeine full-stack project with an empty Motoko backend and a bare React/Tailwind frontend. No existing features, pages, or data models.

## Requested Changes (Diff)

### Add
- **User Account System**: Signup, Login, personal dashboard using Caffeine authorization component.
- **Body Calculator Section**: Five calculators -- BMI, BMR, Daily Calorie Needs, Ideal Body Weight, Body Fat Percentage -- all computed client-side with formula logic.
- **AI Diet Plan Generator**: Form collecting age, height, weight, gender, activity level, goal (weight loss/gain/muscle gain/office worker/gym user) and diet preference (Indian veg, Indian non-veg, International). Returns a structured multi-meal plan stored and displayed per user.
- **Workout Planner**: Categorized plans (Home/Gym), difficulty levels (Beginner/Intermediate/Advanced), weekly schedule view. Pre-defined workout programs stored in backend.
- **Calorie Tracker Dashboard**: Users log daily food entries with calorie values; daily total tracked per user; history viewable by date.
- **Blog Section**: Admin-seeded fitness articles with title, body, category, date. Public read access.
- **Dark/Light mode toggle**: Persisted in localStorage.
- **Responsive design**: Mobile-first layout throughout.

### Modify
- Nothing to modify (greenfield).

### Remove
- Nothing to remove.

## Implementation Plan
1. Select `authorization` Caffeine component.
2. Generate Motoko backend with:
   - User profile storage (age, height, weight, gender, activity level, goal)
   - Diet plan storage per user (generated plans saved)
   - Calorie log entries per user (date, food name, calories)
   - Blog post storage (seeded with sample articles)
   - Workout plan definitions (seeded programs)
3. Build frontend with:
   - Landing page with hero, features overview, CTA
   - Auth pages (login/signup) wired to authorization component
   - Body Calculators page (tabbed: BMI, BMR, Calories, Ideal Weight, Body Fat)
   - AI Diet Planner page (form + generated plan display, Indian & International options)
   - Workout Planner page (filter by Home/Gym + level, weekly schedule grid)
   - Calorie Tracker page (food log form, daily summary, history)
   - Personal Dashboard (stats summary, quick links to tools)
   - Blog page (article list + detail view)
   - Dark/light mode toggle in header
   - Responsive navbar and footer
