import { Footer } from "@/components/Footer";
import { Navbar } from "@/components/Navbar";
import { Toaster } from "@/components/ui/sonner";
import { BlogPage } from "@/pages/BlogPage";
import { CalculatorsPage } from "@/pages/CalculatorsPage";
import { CalorieTrackerPage } from "@/pages/CalorieTrackerPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { DietPlannerPage } from "@/pages/DietPlannerPage";
import { LandingPage } from "@/pages/LandingPage";
import { WorkoutPlannerPage } from "@/pages/WorkoutPlannerPage";
import {
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";

// ─── Layout ────────────────────────────────────────────────────────────────────

function RootLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <Toaster richColors position="top-right" />
    </div>
  );
}

// ─── Routes ───────────────────────────────────────────────────────────────────

const rootRoute = createRootRoute({
  component: RootLayout,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: LandingPage,
});

const calculatorsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/calculators",
  component: CalculatorsPage,
});

const dietPlannerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/diet-planner",
  component: DietPlannerPage,
});

const workoutPlannerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/workout-planner",
  component: WorkoutPlannerPage,
});

const calorieTrackerRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/calorie-tracker",
  component: CalorieTrackerPage,
});

const dashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/dashboard",
  component: DashboardPage,
});

const blogRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/blog",
  component: BlogPage,
});

// ─── Router ───────────────────────────────────────────────────────────────────

const routeTree = rootRoute.addChildren([
  indexRoute,
  calculatorsRoute,
  dietPlannerRoute,
  workoutPlannerRoute,
  calorieTrackerRoute,
  dashboardRoute,
  blogRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  return <RouterProvider router={router} />;
}
