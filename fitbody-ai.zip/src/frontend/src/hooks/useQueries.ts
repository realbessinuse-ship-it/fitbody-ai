import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type {
  BlogPost,
  DietPlan,
  NutritionData,
  UserProfile,
  WorkoutPlan,
} from "../backend.d";
import { useActor } from "./useActor";

// ─── User Profile ────────────────────────────────────────────────────────────

export function useUserProfile() {
  const { actor, isFetching } = useActor();
  return useQuery<UserProfile | null>({
    queryKey: ["userProfile"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSaveUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error("Not authenticated");
      await actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userProfile"] });
    },
  });
}

// ─── Diet Plan ───────────────────────────────────────────────────────────────

export function useDietPlan() {
  const { actor, isFetching } = useActor();
  return useQuery<DietPlan | null>({
    queryKey: ["dietPlan"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getCallerDietPlan();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSaveDietPlan() {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (plan: DietPlan) => {
      if (!actor) throw new Error("Not authenticated");
      await actor.saveDietPlan(plan);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["dietPlan"] });
    },
  });
}

// ─── Calorie Tracker ─────────────────────────────────────────────────────────

export function useFoodEntries(date: Date) {
  const { actor, isFetching } = useActor();
  const dateTime = BigInt(date.getTime());
  return useQuery<NutritionData[]>({
    queryKey: ["foodEntries", date.toDateString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getEntriesByDate(dateTime);
    },
    enabled: !!actor && !isFetching,
  });
}

export function useLogFood() {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      foodName,
      calories,
      date,
    }: {
      foodName: string;
      calories: bigint;
      date: Date;
    }) => {
      if (!actor) throw new Error("Not authenticated");
      await actor.logFoodEntry(foodName, calories, BigInt(date.getTime()));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: ["foodEntries", variables.date.toDateString()],
      });
    },
  });
}

// ─── Workout Plans ───────────────────────────────────────────────────────────

export function useWorkoutPlans() {
  const { actor, isFetching } = useActor();
  return useQuery<WorkoutPlan[]>({
    queryKey: ["workoutPlans"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllWorkoutPlans();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useWorkoutPlansByCategory(category: string) {
  const { actor, isFetching } = useActor();
  return useQuery<WorkoutPlan[]>({
    queryKey: ["workoutPlans", "category", category],
    queryFn: async () => {
      if (!actor) return [];
      if (category === "All") return actor.getAllWorkoutPlans();
      return actor.getWorkoutPlansByCategory(category);
    },
    enabled: !!actor && !isFetching,
  });
}

// ─── Blog Posts ───────────────────────────────────────────────────────────────

export function useBlogPosts() {
  const { actor, isFetching } = useActor();
  return useQuery<BlogPost[]>({
    queryKey: ["blogPosts"],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllBlogPosts();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useBlogPostsByCategory(category: string) {
  const { actor, isFetching } = useActor();
  return useQuery<BlogPost[]>({
    queryKey: ["blogPosts", "category", category],
    queryFn: async () => {
      if (!actor) return [];
      if (category === "All") return actor.getAllBlogPosts();
      return actor.getBlogPostsByCategory(category);
    },
    enabled: !!actor && !isFetching,
  });
}
