import { useEffect } from "react";

interface MetaTags {
  title?: string;
  description?: string;
  ogImage?: string;
  ogType?: string;
}

export function useMetaTags({
  title,
  description,
  ogImage,
  ogType = "website",
}: MetaTags) {
  useEffect(() => {
    const appName = "FitBody AI";
    const fullTitle = title ? `${title} | ${appName}` : appName;
    const defaultDesc =
      "AI-powered fitness platform for personalized diet plans, workout programs, and body analytics.";
    const finalDesc = description || defaultDesc;

    document.title = fullTitle;

    const setMeta = (property: string, content: string, isName = false) => {
      const attr = isName ? "name" : "property";
      let el = document.querySelector(`meta[${attr}="${property}"]`);
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, property);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    setMeta("description", finalDesc, true);
    setMeta("og:title", fullTitle);
    setMeta("og:description", finalDesc);
    setMeta("og:type", ogType);
    if (ogImage) {
      setMeta(
        "og:image",
        ogImage.startsWith("http")
          ? ogImage
          : `${window.location.origin}${ogImage}`,
      );
    }
    setMeta("twitter:card", ogImage ? "summary_large_image" : "summary", true);
    setMeta("twitter:title", fullTitle, true);
    setMeta("twitter:description", finalDesc, true);
  }, [title, description, ogImage, ogType]);
}
