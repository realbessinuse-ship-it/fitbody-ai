import type { BlogPost } from "../backend.d";

export const FALLBACK_BLOG_POSTS: BlogPost[] = [
  {
    id: BigInt(1),
    title: "The Science of Progressive Overload: Why You Must Keep Pushing",
    body: `Progressive overload is the fundamental principle driving every muscular adaptation in the human body. Without it, your muscles adapt to a stimulus and stop growing.

The principle is simple: gradually increase the demands on your musculoskeletal system to continue making gains. This can be achieved through increasing weight, volume (sets × reps), frequency, or reducing rest periods.

Research shows that untrained individuals can increase strength by 25–35% in just 12 weeks with consistent progressive overload. For experienced lifters, even 2–5% gains per month are meaningful.

**Practical Application:**
- Add 2.5 kg to compound lifts every 1–2 weeks
- Increase reps from 8 to 12 before adding weight
- Track every session — what gets measured gets improved
- Deload every 4–6 weeks to allow full recovery

The body is a remarkably adaptive machine. Give it a reason to grow stronger and it will — but only if you consistently challenge it beyond its comfort zone.`,
    category: "Training",
    author: "Dr. Arjun Mehta",
    publishedDate: BigInt(new Date("2026-02-15").getTime()),
  },
  {
    id: BigInt(2),
    title: "Indian Diet for Muscle Gain: The Complete High-Protein Guide",
    body: `Building muscle on an Indian diet is entirely possible — and delicious. The key is strategically combining protein sources throughout the day to hit your daily targets of 1.6–2.2g protein per kg bodyweight.

**Top Indian Protein Sources:**

*Vegetarian (per 100g):*
- Paneer: 18g protein, excellent leucine content
- Rajma (Kidney Beans): 24g protein (cooked)
- Moong Dal: 22g protein (cooked) 
- Greek Yogurt (Dahi): 10g protein
- Tofu: 17g protein

*Non-Vegetarian:*
- Chicken Breast: 31g protein
- Eggs: 13g protein + complete amino acid profile
- Fish (Rohu/Pomfret): 20-25g protein
- Paneer (cottage cheese equivalent)

**Sample 3000 kcal Muscle Building Day:**
- Breakfast: 4 eggs + 2 roti + rajma curry (650 kcal, 45g protein)
- Mid-Morning: Paneer bhurji + fruits (400 kcal, 25g protein)
- Lunch: 200g chicken + dal + 2 cups rice + salad (750 kcal, 55g protein)
- Pre-Workout: Banana + 20g protein shake (250 kcal, 22g protein)
- Dinner: 2 roti + mixed dal + curd (500 kcal, 30g protein)

Total: ~2,550 kcal, 177g protein — adjust portions for your specific TDEE.`,
    category: "Nutrition",
    author: "Priya Sharma, RD",
    publishedDate: BigInt(new Date("2026-02-20").getTime()),
  },
  {
    id: BigInt(3),
    title: "Sleep: The Underrated Performance Enhancer You're Ignoring",
    body: `You can train perfectly, eat optimally, and still underperform — if you're sleeping less than 7 hours per night. Sleep is when your body does the actual work of building muscle, consolidating motor patterns, and restoring hormonal balance.

**What Happens During Sleep:**
- Growth hormone peaks during deep sleep (3am–5am typically)
- Muscle protein synthesis accelerates during REM cycles
- Cortisol (the stress/breakdown hormone) normalizes
- Neural pathways for motor skills get consolidated

**The Research Is Clear:**
A Stanford study showed basketball players who extended sleep to 10 hours improved sprint times by 5% and shooting accuracy by 9%. Another study found that restricting sleep to 5.5 hours led to 60% less muscle gain during a caloric surplus compared to 8.5 hours.

**Sleep Optimization Protocol:**
1. Fixed wake time (even on weekends) — this anchors your circadian rhythm
2. Keep bedroom below 19°C — body temperature must drop for sleep onset
3. No screens 60 min before bed — blue light suppresses melatonin by 50%
4. Consistent sleep time — aim for 10pm–6am window
5. Magnesium glycinate (400mg) before bed improves deep sleep quality

Treat sleep like training. Schedule it. Protect it. Your gains depend on it.`,
    category: "Recovery",
    author: "Coach Vikram Singh",
    publishedDate: BigInt(new Date("2026-02-25").getTime()),
  },
  {
    id: BigInt(4),
    title: "HIIT vs. Steady-State Cardio: Which Burns More Fat?",
    body: `The HIIT vs. steady-state cardio debate has generated more confusion in fitness than almost any other topic. Here's what the research actually shows.

**HIIT (High-Intensity Interval Training)**
- Burns 25–30% more calories than moderate-intensity cardio in the same time
- Creates EPOC (Excess Post-Exercise Oxygen Consumption) — metabolism stays elevated 24–48 hours
- Preserves muscle mass better during fat loss phases
- Time-efficient: 20-minute HIIT ≈ 40-minute steady state

**Steady-State Cardio**
- Lower injury risk, sustainable for long durations
- Better for active recovery on rest days
- Improves aerobic base which enhances recovery between lifting sets
- Easier to adhere to long-term for many people

**The Real Answer:**
Both work. Neither is superior for everyone. The best cardio is the type you'll consistently do.

For fat loss specifically: HIIT 2–3x/week + 1–2 steady-state sessions creates the ideal balance of caloric expenditure, recovery, and muscle preservation.

**FitBody AI Recommendation:**
If you're time-constrained: 20-min HIIT 3x/week
If you have joint issues: 45-min brisk walking or cycling daily
If you're advanced: Polarized training (80% low, 20% high intensity)`,
    category: "Training",
    author: "Rahul Nair, CSCS",
    publishedDate: BigInt(new Date("2026-02-28").getTime()),
  },
  {
    id: BigInt(5),
    title: "Intermittent Fasting for Indians: Adapting IF to Our Food Culture",
    body: `Intermittent fasting has taken the health world by storm, but most protocols were designed around Western eating patterns. Here's how to adapt IF to Indian food culture and meal timing.

**Popular IF Protocols:**
- 16:8 — Fast 16 hours, eat within 8-hour window (most popular)
- 5:2 — Eat normally 5 days, restrict to 500 kcal on 2 days
- OMAD — One meal a day (advanced, not recommended for most)

**Adapting to Indian Meal Culture:**
Indian families typically eat 3 main meals with family. IF can conflict with social eating norms. Solution: Use a 12:12 or 14:10 protocol instead — easier to maintain culturally.

**Practical 16:8 for Indians:**
- Stop eating at 9pm after dinner
- Skip breakfast, break fast at 1pm with a substantial lunch
- Dal + rice + sabzi + curd = ideal breaking-fast meal
- Evening meal by 7–8pm

**Who Benefits Most:**
- Those with high insulin resistance
- People with sedentary jobs (office workers)
- Those who aren't hungry in the morning anyway

**Who Should NOT Fast:**
- Underweight individuals
- Pregnant or breastfeeding women  
- Those with a history of eating disorders
- High-performance athletes during training blocks

Always consult your doctor before starting any fasting protocol.`,
    category: "Nutrition",
    author: "Dr. Neha Joshi, MD",
    publishedDate: BigInt(new Date("2026-03-01").getTime()),
  },
  {
    id: BigInt(6),
    title: "The Perfect Warm-Up Routine: Activate, Mobilize, Perform",
    body: `The warm-up is the most skipped component of training — and the most important for injury prevention and performance optimization. A proper warm-up takes 10–15 minutes and dramatically improves your workout quality.

**The 3-Phase Warm-Up Framework:**

**Phase 1 — General Warm-Up (3 min)**
Light cardio to raise core temperature:
- Jumping jacks, jogging in place, skipping
- Goal: Break a light sweat, heart rate to ~100 BPM

**Phase 2 — Mobility & Flexibility (5 min)**
Dynamic stretching (never static before training):
- Hip circles × 10 each direction
- Arm swings × 15 each direction  
- Leg swings (forward + lateral) × 10
- World's greatest stretch × 5 each side
- Thoracic rotation × 10 each side

**Phase 3 — Activation (5 min)**
Wake up the muscles you're about to train:
- For Leg Day: Glute bridges × 20, Clamshells × 15, Monster walks
- For Push Day: Band pull-aparts × 20, Scapular push-ups × 15
- For Pull Day: Dead hangs 30s, Band face pulls × 20

**The Science Behind It:**
- Muscle temperature increase of 1°C improves contractile force by 2–3%
- Synovial fluid in joints becomes less viscous, improving range of motion
- Motor patterns for the upcoming exercise get primed through activation

Your warm-up is an investment that pays dividends in performance and injury-free training for years to come.`,
    category: "Training",
    author: "Aditya Kapoor, PT",
    publishedDate: BigInt(new Date("2026-03-01").getTime()),
  },
];
