import { Link } from "@tanstack/react-router";
import { Heart, Zap } from "lucide-react";

export function Footer() {
  const year = new Date().getFullYear();
  const hostname =
    typeof window !== "undefined" ? window.location.hostname : "";
  const caffeineUrl = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(hostname)}`;

  return (
    <footer className="border-t border-border/50 bg-card/30">
      <div className="container mx-auto px-4 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary shadow-lime-sm">
                <Zap className="h-4 w-4 text-primary-foreground fill-current" />
              </div>
              <span className="font-display text-[1.05rem] font-black tracking-tight">
                FitBody <span className="text-gradient-lime">AI</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-[200px]">
              Train smarter. Eat better. Live stronger with AI-powered fitness
              tools.
            </p>
          </div>

          {/* Tools */}
          <div>
            <h4 className="font-display font-black text-xs uppercase tracking-widest text-foreground/60 mb-4">
              Tools
            </h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li>
                <Link
                  to="/calculators"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Body Calculators
                </Link>
              </li>
              <li>
                <Link
                  to="/diet-planner"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Diet Planner
                </Link>
              </li>
              <li>
                <Link
                  to="/workout-planner"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Workout Planner
                </Link>
              </li>
              <li>
                <Link
                  to="/calorie-tracker"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Calorie Tracker
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-display font-black text-xs uppercase tracking-widest text-foreground/60 mb-4">
              Resources
            </h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li>
                <Link
                  to="/blog"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Fitness Blog
                </Link>
              </li>
              <li>
                <Link
                  to="/dashboard"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Dashboard
                </Link>
              </li>
              <li>
                <Link
                  to="/"
                  className="hover:text-primary transition-colors duration-150"
                >
                  Home
                </Link>
              </li>
            </ul>
          </div>

          {/* Stats */}
          <div>
            <h4 className="font-display font-black text-xs uppercase tracking-widest text-foreground/60 mb-4">
              By the Numbers
            </h4>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "Calculators", value: "5+" },
                { label: "Diet Plans", value: "8+" },
                { label: "Workouts", value: "6+" },
                { label: "Blog Posts", value: "6+" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="bg-muted/40 rounded-xl p-3 text-center border border-border/30"
                >
                  <div className="stat-number text-xl text-gradient-lime">
                    {stat.value}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-border/40 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
          <p>
            © {year}. Built with{" "}
            <Heart className="inline h-3.5 w-3.5 text-red-500 fill-red-500 mx-0.5" />{" "}
            using{" "}
            <a
              href={caffeineUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline font-medium"
            >
              caffeine.ai
            </a>
          </p>
          <p className="text-xs text-muted-foreground/60">
            Powered by Internet Computer · Decentralized &amp; Secure
          </p>
        </div>
      </div>
    </footer>
  );
}
