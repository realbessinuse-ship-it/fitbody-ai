import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FALLBACK_BLOG_POSTS } from "@/data/fallbackBlogPosts";
import { useMetaTags } from "@/hooks/useMetaTags";
import { useBlogPosts } from "@/hooks/useQueries";
import { BookOpen, ChevronRight, Clock, Tag, User, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import type { BlogPost } from "../backend.d";

const CATEGORIES = ["All", "Nutrition", "Training", "Recovery"];

const CATEGORY_COLORS: Record<string, string> = {
  Nutrition: "bg-chart-1/10 text-chart-1 border-chart-1/20",
  Training: "bg-chart-3/10 text-chart-3 border-chart-3/20",
  Recovery: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  Fitness: "bg-primary/10 text-primary border-primary/20",
};

function formatDate(timestamp: bigint) {
  const date = new Date(Number(timestamp));
  return date.toLocaleDateString("en-IN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function estimateReadTime(body: string) {
  const words = body.split(/\s+/).length;
  return Math.max(1, Math.ceil(words / 200));
}

function BlogArticleModal({
  post,
  onClose,
}: {
  post: BlogPost;
  onClose: () => void;
}) {
  const readTime = estimateReadTime(post.body);

  const formatBody = (body: string) => {
    return body.split("\n\n").map((paragraph) => {
      const paraKey = paragraph.slice(0, 30);
      if (paragraph.startsWith("**") && paragraph.endsWith("**")) {
        return (
          <h3
            key={paraKey}
            className="font-display text-lg font-bold mt-6 mb-2"
          >
            {paragraph.slice(2, -2)}
          </h3>
        );
      }
      const parts = paragraph.split(/(\*\*[^*]+\*\*)/g);
      return (
        <p key={paraKey} className="text-muted-foreground leading-relaxed mb-4">
          {parts.map((part) => {
            const partKey = part.slice(0, 20);
            if (part.startsWith("**") && part.endsWith("**")) {
              return (
                <strong key={partKey} className="text-foreground">
                  {part.slice(2, -2)}
                </strong>
              );
            }
            const bulletParts = part.split(/^- /gm);
            if (bulletParts.length > 1) {
              return (
                <span key={partKey}>
                  {bulletParts.map((bp) =>
                    bp === bulletParts[0] ? (
                      bp
                    ) : (
                      <span key={bp.slice(0, 20)} className="block pl-4">
                        • {bp}
                      </span>
                    ),
                  )}
                </span>
              );
            }
            return part;
          })}
        </p>
      );
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-8 bg-background/80 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.96 }}
        className="relative w-full max-w-2xl rounded-2xl border border-border/50 bg-card shadow-lime-sm my-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 z-10 rounded-lg bg-muted/80 p-2 hover:bg-muted transition-colors"
          aria-label="Close article"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="p-8">
          {/* Meta */}
          <div className="flex items-center gap-2 flex-wrap mb-4">
            <Badge
              variant="outline"
              className={CATEGORY_COLORS[post.category] || "bg-muted/50"}
            >
              <Tag className="h-3 w-3 mr-1" />
              {post.category}
            </Badge>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              {readTime} min read
            </span>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <User className="h-3 w-3" />
              {post.author}
            </span>
          </div>

          <h2 className="font-display text-2xl font-black mb-2 leading-tight">
            {post.title}
          </h2>
          <p className="text-xs text-muted-foreground mb-6">
            {formatDate(post.publishedDate)}
          </p>

          <div className="prose-sm max-w-none">{formatBody(post.body)}</div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function BlogCard({ post, onRead }: { post: BlogPost; onRead: () => void }) {
  const readTime = estimateReadTime(post.body);
  const snippet = `${post.body.slice(0, 150).replace(/\*\*/g, "").trim()}...`;

  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="group rounded-2xl border border-border/50 bg-card hover:border-primary/30 hover:shadow-lime-sm transition-all duration-300 p-6 flex flex-col"
    >
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        <Badge
          variant="outline"
          className={`text-xs ${CATEGORY_COLORS[post.category] || "bg-muted/50"}`}
        >
          {post.category}
        </Badge>
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          {readTime} min read
        </span>
      </div>

      <h3 className="font-display font-bold text-lg leading-tight mb-2 group-hover:text-primary transition-colors flex-1">
        {post.title}
      </h3>

      <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">
        {snippet}
      </p>

      <div className="flex items-center justify-between mt-auto pt-3 border-t border-border/30">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <User className="h-3 w-3" />
          <span>{post.author}</span>
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={onRead}
          className="gap-1.5 text-xs hover:text-primary"
        >
          Read More
          <ChevronRight className="h-3 w-3" />
        </Button>
      </div>
    </motion.article>
  );
}

function SkeletonCard() {
  return (
    <div className="rounded-2xl border border-border/50 bg-card p-6 space-y-3">
      <div className="flex gap-2">
        <Skeleton className="h-5 w-20" />
        <Skeleton className="h-5 w-16" />
      </div>
      <Skeleton className="h-6 w-4/5" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-3/4" />
      <div className="flex justify-between pt-2">
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-8 w-20" />
      </div>
    </div>
  );
}

export function BlogPage() {
  useMetaTags({
    title: "Fitness Blog",
    description:
      "Expert fitness articles on nutrition, training, recovery, and building lasting healthy habits.",
  });

  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  const { data: backendPosts = [], isLoading } = useBlogPosts();
  const allPosts = backendPosts.length > 0 ? backendPosts : FALLBACK_BLOG_POSTS;

  const filteredPosts =
    activeCategory === "All"
      ? allPosts
      : allPosts.filter((p) => p.category === activeCategory);

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mb-10"
        >
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            <BookOpen className="h-3.5 w-3.5 mr-1.5" />
            Expert Knowledge
          </Badge>
          <h1 className="font-display text-4xl lg:text-5xl font-black tracking-tight mb-4">
            Fitness <span className="text-gradient-lime">Blog</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Evidence-based articles on nutrition, training, recovery, and
            building sustainable fitness habits.
          </p>
        </motion.div>

        {/* Category filter */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Tabs value={activeCategory} onValueChange={setActiveCategory}>
            <TabsList className="bg-muted/50 p-1">
              {CATEGORIES.map((cat) => (
                <TabsTrigger
                  key={cat}
                  value={cat}
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-md"
                >
                  {cat}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </motion.div>

        <div className="text-sm text-muted-foreground mb-6">
          {filteredPosts.length} article{filteredPosts.length !== 1 ? "s" : ""}
          {activeCategory !== "All" ? ` in ${activeCategory}` : ""}
        </div>

        {/* Articles grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-5xl mb-4">📚</div>
            <h3 className="font-display text-xl font-bold mb-2">
              No articles in this category
            </h3>
            <p className="text-muted-foreground text-sm">
              Check back later for new content!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <BlogCard
                key={String(post.id)}
                post={post}
                onRead={() => setSelectedPost(post)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Article modal */}
      <AnimatePresence>
        {selectedPost && (
          <BlogArticleModal
            post={selectedPost}
            onClose={() => setSelectedPost(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
