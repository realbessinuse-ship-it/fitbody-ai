import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMetaTags } from "@/hooks/useMetaTags";
import { Activity, Calculator, Percent, Target, Weight } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";

// ─── BMI Calculator ───────────────────────────────────────────────────────────

function getBMICategory(bmi: number) {
  if (bmi < 18.5)
    return { label: "Underweight", color: "text-blue-500", bg: "bg-blue-500" };
  if (bmi < 25)
    return {
      label: "Normal Weight",
      color: "text-green-500",
      bg: "bg-green-500",
    };
  if (bmi < 30)
    return {
      label: "Overweight",
      color: "text-yellow-500",
      bg: "bg-yellow-500",
    };
  return { label: "Obese", color: "text-red-500", bg: "bg-red-500" };
}

function BMICalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [result, setResult] = useState<number | null>(null);

  const calculate = () => {
    const w = Number.parseFloat(weight);
    const h = Number.parseFloat(height) / 100;
    if (w > 0 && h > 0) {
      setResult(Math.round((w / (h * h)) * 10) / 10);
    }
  };

  const category = result ? getBMICategory(result) : null;
  const progress = result ? Math.min((result / 40) * 100, 100) : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Weight (kg)</Label>
          <Input
            type="number"
            placeholder="70"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Height (cm)</Label>
          <Input
            type="number"
            placeholder="175"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
        </div>
      </div>
      <Button
        onClick={calculate}
        className="w-full bg-primary text-primary-foreground"
      >
        Calculate BMI
      </Button>
      {result && category && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-border/50 bg-card p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="font-display text-4xl font-black">{result}</div>
              <div className="text-sm text-muted-foreground mt-1">
                BMI Score
              </div>
            </div>
            <Badge
              className={`${category.color} border-current bg-transparent text-lg px-4 py-1.5`}
            >
              {category.label}
            </Badge>
          </div>
          <Progress value={progress} className="h-3" />
          <div className="grid grid-cols-4 gap-2 text-xs text-center">
            {[
              { range: "< 18.5", label: "Underweight", color: "text-blue-500" },
              { range: "18.5–24.9", label: "Normal", color: "text-green-500" },
              {
                range: "25–29.9",
                label: "Overweight",
                color: "text-yellow-500",
              },
              { range: "> 30", label: "Obese", color: "text-red-500" },
            ].map((item) => (
              <div key={item.label} className="space-y-1">
                <div className={`font-bold ${item.color}`}>{item.range}</div>
                <div className="text-muted-foreground">{item.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── BMR Calculator ───────────────────────────────────────────────────────────

function BMRCalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [result, setResult] = useState<number | null>(null);

  const calculate = () => {
    const w = Number.parseFloat(weight);
    const h = Number.parseFloat(height);
    const a = Number.parseFloat(age);
    if (w > 0 && h > 0 && a > 0) {
      const bmr =
        gender === "male"
          ? 10 * w + 6.25 * h - 5 * a + 5
          : 10 * w + 6.25 * h - 5 * a - 161;
      setResult(Math.round(bmr));
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Weight (kg)</Label>
          <Input
            type="number"
            placeholder="70"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Height (cm)</Label>
          <Input
            type="number"
            placeholder="175"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Age (years)</Label>
          <Input
            type="number"
            placeholder="25"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Gender</Label>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button
        onClick={calculate}
        className="w-full bg-primary text-primary-foreground"
      >
        Calculate BMR
      </Button>
      {result && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-border/50 bg-card p-6"
        >
          <div className="text-center">
            <div className="font-display text-5xl font-black text-gradient-lime">
              {result.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground mt-2">
              Calories / Day (BMR)
            </div>
            <p className="text-sm text-muted-foreground mt-4 max-w-sm mx-auto">
              This is the number of calories your body burns at complete rest.
              Your actual daily needs will be higher based on activity level.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── Daily Calories (TDEE) ────────────────────────────────────────────────────

const ACTIVITY_MULTIPLIERS = [
  { value: "1.2", label: "Sedentary", desc: "Little or no exercise" },
  { value: "1.375", label: "Lightly Active", desc: "1-3 days/week" },
  { value: "1.55", label: "Moderately Active", desc: "3-5 days/week" },
  { value: "1.725", label: "Very Active", desc: "6-7 days/week" },
  {
    value: "1.9",
    label: "Extremely Active",
    desc: "Hard exercise + physical job",
  },
];

function DailyCaloriesCalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("male");
  const [activity, setActivity] = useState("1.55");
  const [result, setResult] = useState<number | null>(null);

  const calculate = () => {
    const w = Number.parseFloat(weight);
    const h = Number.parseFloat(height);
    const a = Number.parseFloat(age);
    const m = Number.parseFloat(activity);
    if (w > 0 && h > 0 && a > 0) {
      const bmr =
        gender === "male"
          ? 10 * w + 6.25 * h - 5 * a + 5
          : 10 * w + 6.25 * h - 5 * a - 161;
      setResult(Math.round(bmr * m));
    }
  };

  const activityLabel = ACTIVITY_MULTIPLIERS.find(
    (a) => a.value === activity,
  )?.label;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Weight (kg)</Label>
          <Input
            type="number"
            placeholder="70"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Height (cm)</Label>
          <Input
            type="number"
            placeholder="175"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Age (years)</Label>
          <Input
            type="number"
            placeholder="25"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Gender</Label>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <Label>Activity Level</Label>
        <Select value={activity} onValueChange={setActivity}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {ACTIVITY_MULTIPLIERS.map((a) => (
              <SelectItem key={a.value} value={a.value}>
                {a.label} — {a.desc}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button
        onClick={calculate}
        className="w-full bg-primary text-primary-foreground"
      >
        Calculate Daily Calories
      </Button>
      {result && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-border/50 bg-card p-6 space-y-4"
        >
          <div className="text-center mb-4">
            <div className="font-display text-5xl font-black text-gradient-lime">
              {result.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground mt-2">
              Total Daily Energy Expenditure (TDEE) • {activityLabel}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              {
                label: "Weight Loss",
                value: result - 500,
                color: "text-blue-500",
              },
              { label: "Maintenance", value: result, color: "text-primary" },
              {
                label: "Weight Gain",
                value: result + 500,
                color: "text-energy",
              },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-lg bg-muted/50 p-3 text-center"
              >
                <div
                  className={`font-display text-xl font-black ${item.color}`}
                >
                  {item.value.toLocaleString()}
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {item.label}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── Ideal Weight ─────────────────────────────────────────────────────────────

function IdealWeightCalculator() {
  const [height, setHeight] = useState("");
  const [gender, setGender] = useState("male");
  const [result, setResult] = useState<{
    devine: number;
    range: [number, number];
  } | null>(null);

  const calculate = () => {
    const h = Number.parseFloat(height);
    if (h > 0) {
      const heightInches = h / 2.54;
      const inches_over_60 = Math.max(0, heightInches - 60);
      const devine =
        gender === "male"
          ? 50 + 2.3 * inches_over_60
          : 45.5 + 2.3 * inches_over_60;
      setResult({
        devine: Math.round(devine * 10) / 10,
        range: [
          Math.round((devine - 2.3) * 10) / 10,
          Math.round((devine + 2.3) * 10) / 10,
        ],
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Height (cm)</Label>
          <Input
            type="number"
            placeholder="175"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Gender</Label>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Button
        onClick={calculate}
        className="w-full bg-primary text-primary-foreground"
      >
        Calculate Ideal Weight
      </Button>
      {result && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-border/50 bg-card p-6 text-center"
        >
          <div className="font-display text-5xl font-black text-gradient-lime">
            {result.devine} kg
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            Ideal Body Weight (Devine Formula)
          </div>
          <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm text-primary">
            Healthy range: {result.range[0]} – {result.range[1]} kg
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── Body Fat % ───────────────────────────────────────────────────────────────

function getBodyFatCategory(bf: number, gender: string) {
  if (gender === "male") {
    if (bf < 6) return { label: "Essential Fat", color: "text-blue-500" };
    if (bf < 14) return { label: "Athletic", color: "text-primary" };
    if (bf < 18) return { label: "Fitness", color: "text-green-500" };
    if (bf < 25) return { label: "Average", color: "text-yellow-500" };
    return { label: "Obese", color: "text-red-500" };
  }
  if (bf < 14) return { label: "Essential Fat", color: "text-blue-500" };
  if (bf < 21) return { label: "Athletic", color: "text-primary" };
  if (bf < 25) return { label: "Fitness", color: "text-green-500" };
  if (bf < 32) return { label: "Average", color: "text-yellow-500" };
  return { label: "Obese", color: "text-red-500" };
}

function BodyFatCalculator() {
  const [height, setHeight] = useState("");
  const [neck, setNeck] = useState("");
  const [waist, setWaist] = useState("");
  const [hip, setHip] = useState("");
  const [gender, setGender] = useState("male");
  const [result, setResult] = useState<number | null>(null);

  const calculate = () => {
    const h = Number.parseFloat(height);
    const n = Number.parseFloat(neck);
    const w = Number.parseFloat(waist);
    const hh = Number.parseFloat(hip);

    if (h > 0 && n > 0 && w > 0) {
      let bf: number;
      if (gender === "male") {
        bf = 86.01 * Math.log10(w - n) - 70.041 * Math.log10(h) + 36.76;
      } else {
        if (!hh || hh <= 0) return;
        bf = 163.205 * Math.log10(w + hh - n) - 97.684 * Math.log10(h) - 78.387;
      }
      setResult(Math.round(bf * 10) / 10);
    }
  };

  const category = result ? getBodyFatCategory(result, gender) : null;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Gender</Label>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Height (cm)</Label>
          <Input
            type="number"
            placeholder="175"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Neck circumference (cm)</Label>
          <Input
            type="number"
            placeholder="38"
            value={neck}
            onChange={(e) => setNeck(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Waist circumference (cm)</Label>
          <Input
            type="number"
            placeholder="85"
            value={waist}
            onChange={(e) => setWaist(e.target.value)}
          />
        </div>
        {gender === "female" && (
          <div className="space-y-2 col-span-2">
            <Label>Hip circumference (cm)</Label>
            <Input
              type="number"
              placeholder="95"
              value={hip}
              onChange={(e) => setHip(e.target.value)}
            />
          </div>
        )}
      </div>
      <Button
        onClick={calculate}
        className="w-full bg-primary text-primary-foreground"
      >
        Calculate Body Fat %
      </Button>
      {result !== null && category && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-border/50 bg-card p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="font-display text-5xl font-black text-gradient-lime">
                {result}%
              </div>
              <div className="text-sm text-muted-foreground mt-1">
                Body Fat Percentage
              </div>
            </div>
            <Badge
              className={`${category.color} border-current bg-transparent text-base px-3 py-1`}
            >
              {category.label}
            </Badge>
          </div>
          <Progress value={Math.min(result, 50)} className="mt-4 h-3" />
        </motion.div>
      )}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

const TABS = [
  { value: "bmi", label: "BMI", icon: Weight },
  { value: "bmr", label: "BMR", icon: Activity },
  { value: "calories", label: "Daily Calories", icon: Calculator },
  { value: "ideal-weight", label: "Ideal Weight", icon: Target },
  { value: "body-fat", label: "Body Fat %", icon: Percent },
];

export function CalculatorsPage() {
  useMetaTags({
    title: "Body Calculators",
    description:
      "Calculate your BMI, BMR, daily calorie needs, ideal weight, and body fat percentage with our AI-powered body calculators.",
  });

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mb-10"
        >
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            <Calculator className="h-3.5 w-3.5 mr-1.5" />
            Body Analytics
          </Badge>
          <h1 className="font-display text-4xl lg:text-5xl font-black tracking-tight mb-4">
            Body <span className="text-gradient-lime">Calculators</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Evidence-based calculations using clinically validated formulas. All
            computations are done locally — no data sent to servers.
          </p>
        </motion.div>

        {/* Calculator tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Tabs defaultValue="bmi">
            <TabsList className="flex flex-wrap h-auto gap-1 mb-8 bg-muted/50 p-1.5 rounded-xl">
              {TABS.map((tab) => (
                <TabsTrigger
                  key={tab.value}
                  value={tab.value}
                  className="flex items-center gap-1.5 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <tab.icon className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                  <span className="sm:hidden">{tab.label.split(" ")[0]}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            <div className="max-w-2xl">
              <div className="rounded-2xl border border-border/50 bg-card p-6 shadow-xs">
                <TabsContent value="bmi" className="mt-0">
                  <h2 className="font-display text-xl font-bold mb-1">
                    BMI Calculator
                  </h2>
                  <p className="text-sm text-muted-foreground mb-6">
                    Body Mass Index — weight relative to height.
                  </p>
                  <BMICalculator />
                </TabsContent>

                <TabsContent value="bmr" className="mt-0">
                  <h2 className="font-display text-xl font-bold mb-1">
                    BMR Calculator
                  </h2>
                  <p className="text-sm text-muted-foreground mb-6">
                    Basal Metabolic Rate — calories burned at complete rest
                    (Mifflin-St Jeor formula).
                  </p>
                  <BMRCalculator />
                </TabsContent>

                <TabsContent value="calories" className="mt-0">
                  <h2 className="font-display text-xl font-bold mb-1">
                    Daily Calories (TDEE)
                  </h2>
                  <p className="text-sm text-muted-foreground mb-6">
                    Total Daily Energy Expenditure — how many calories you burn
                    each day based on activity.
                  </p>
                  <DailyCaloriesCalculator />
                </TabsContent>

                <TabsContent value="ideal-weight" className="mt-0">
                  <h2 className="font-display text-xl font-bold mb-1">
                    Ideal Weight Calculator
                  </h2>
                  <p className="text-sm text-muted-foreground mb-6">
                    Your healthy weight target using the Devine formula.
                  </p>
                  <IdealWeightCalculator />
                </TabsContent>

                <TabsContent value="body-fat" className="mt-0">
                  <h2 className="font-display text-xl font-bold mb-1">
                    Body Fat % Calculator
                  </h2>
                  <p className="text-sm text-muted-foreground mb-6">
                    Estimate body fat using the US Navy circumference method.
                  </p>
                  <BodyFatCalculator />
                </TabsContent>
              </div>
            </div>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}
