import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useInternetIdentity } from "@/hooks/useInternetIdentity";
import { useMetaTags } from "@/hooks/useMetaTags";
import { useFoodEntries, useLogFood } from "@/hooks/useQueries";
import { Link } from "@tanstack/react-router";
import {
  ChevronLeft,
  ChevronRight,
  Flame,
  Loader2,
  Lock,
  Plus,
  Trash2,
  TrendingUp,
} from "lucide-react";
import { motion } from "motion/react";
import { useRef, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { toast } from "sonner";
import type { NutritionData } from "../backend.d";

const DAILY_GOAL = 2000;

const CHART_COLORS = [
  "oklch(0.87 0.25 128)",
  "oklch(0.75 0.24 26)",
  "oklch(0.65 0.22 265)",
  "oklch(0.68 0.2 180)",
  "oklch(0.78 0.18 50)",
];

function formatDate(date: Date) {
  return date.toLocaleDateString("en-IN", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function dateKey(date: Date) {
  return date.toISOString().split("T")[0];
}

function LoginPrompt() {
  const { login, isLoggingIn } = useInternetIdentity();
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="inline-flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10 mb-6">
          <Lock className="h-10 w-10 text-primary" />
        </div>
        <h2 className="font-display text-2xl font-black mb-3">
          Login Required
        </h2>
        <p className="text-muted-foreground mb-6">
          Track your daily calories and food intake. Login to save your
          progress.
        </p>
        <Button
          onClick={login}
          disabled={isLoggingIn}
          className="gap-2 bg-primary text-primary-foreground shadow-lime-sm"
        >
          {isLoggingIn ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <TrendingUp className="h-4 w-4" />
          )}
          {isLoggingIn ? "Connecting..." : "Login to Track Calories"}
        </Button>
      </div>
    </div>
  );
}

export function CalorieTrackerPage() {
  useMetaTags({
    title: "Calorie Tracker",
    description:
      "Log your daily food intake and track calories with FitBody AI's intuitive calorie tracker.",
  });

  const { identity } = useInternetIdentity();
  const isAuthenticated = !!identity;

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [foodName, setFoodName] = useState("");
  const [calories, setCalories] = useState("");
  const foodInputRef = useRef<HTMLInputElement>(null);

  const { data: entries = [], isLoading } = useFoodEntries(selectedDate);
  const logFoodMutation = useLogFood();

  const totalCalories = entries.reduce(
    (sum: number, e: NutritionData) => sum + Number(e.calories),
    0,
  );
  const progressPct = Math.min((totalCalories / DAILY_GOAL) * 100, 100);

  const navigateDate = (direction: -1 | 1) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + direction);
    setSelectedDate(newDate);
  };

  const handleAddFood = async () => {
    if (!foodName.trim() || !calories) {
      toast.error("Please enter both food name and calories.");
      return;
    }
    const cal = Number.parseInt(calories);
    if (Number.isNaN(cal) || cal <= 0) {
      toast.error("Please enter a valid calorie amount.");
      return;
    }

    try {
      await logFoodMutation.mutateAsync({
        foodName: foodName.trim(),
        calories: BigInt(cal),
        date: selectedDate,
      });
      setFoodName("");
      setCalories("");
      foodInputRef.current?.focus();
      toast.success(`Logged: ${foodName} (${cal} kcal)`);
    } catch {
      toast.error("Failed to log food. Please try again.");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleAddFood();
  };

  const chartData = entries.slice(0, 5).map((e: NutritionData, i: number) => ({
    name: e.foodName,
    value: Number(e.calories),
    color: CHART_COLORS[i % CHART_COLORS.length],
  }));

  if (!isAuthenticated) return <LoginPrompt />;

  const isToday = dateKey(selectedDate) === dateKey(new Date());
  const progressColor =
    progressPct >= 100
      ? "text-red-500"
      : progressPct >= 80
        ? "text-yellow-500"
        : "text-primary";

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mb-10"
        >
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            <TrendingUp className="h-3.5 w-3.5 mr-1.5" />
            Nutrition Tracking
          </Badge>
          <h1 className="font-display text-4xl lg:text-5xl font-black tracking-tight mb-4">
            Calorie <span className="text-gradient-lime">Tracker</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Log your meals and stay on top of your daily nutrition goals.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-5xl">
          {/* Left: Log + Progress */}
          <div className="lg:col-span-2 space-y-6">
            {/* Date Navigator */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-xl border border-border/50 bg-card p-4 flex items-center justify-between"
            >
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigateDate(-1)}
                aria-label="Previous day"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="text-center">
                <div className="font-display font-bold">
                  {formatDate(selectedDate)}
                </div>
                {isToday && (
                  <Badge className="mt-1 text-xs bg-primary/10 text-primary border-primary/20">
                    Today
                  </Badge>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigateDate(1)}
                disabled={isToday}
                aria-label="Next day"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </motion.div>

            {/* Progress card */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="rounded-xl border border-border/50 bg-card p-5"
            >
              <div className="flex items-end justify-between mb-3">
                <div>
                  <div
                    className={`font-display text-4xl font-black ${progressColor}`}
                  >
                    {totalCalories.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    of {DAILY_GOAL.toLocaleString()} kcal goal
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Flame className={`h-5 w-5 ${progressColor}`} />
                  <span
                    className={`font-display text-xl font-bold ${progressColor}`}
                  >
                    {Math.round(progressPct)}%
                  </span>
                </div>
              </div>
              <Progress value={progressPct} className="h-3" />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>Consumed</span>
                <span>
                  {Math.max(0, DAILY_GOAL - totalCalories).toLocaleString()}{" "}
                  kcal remaining
                </span>
              </div>
            </motion.div>

            {/* Add food */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="rounded-xl border border-border/50 bg-card p-5"
            >
              <h3 className="font-display font-bold mb-4">Log Food</h3>
              <div className="flex gap-3">
                <div className="flex-1 space-y-2">
                  <Label>Food Item</Label>
                  <Input
                    ref={foodInputRef}
                    placeholder="e.g., Dal Tadka"
                    value={foodName}
                    onChange={(e) => setFoodName(e.target.value)}
                    onKeyDown={handleKeyDown}
                  />
                </div>
                <div className="w-28 space-y-2">
                  <Label>Calories (kcal)</Label>
                  <Input
                    type="number"
                    placeholder="350"
                    value={calories}
                    onChange={(e) => setCalories(e.target.value)}
                    onKeyDown={handleKeyDown}
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={handleAddFood}
                    disabled={logFoodMutation.isPending}
                    className="gap-2 bg-primary text-primary-foreground shadow-lime-sm"
                  >
                    {logFoodMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Plus className="h-4 w-4" />
                    )}
                    Add
                  </Button>
                </div>
              </div>
            </motion.div>

            {/* Food log */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="rounded-xl border border-border/50 bg-card p-5"
            >
              <h3 className="font-display font-bold mb-4">
                Food Log
                {entries.length > 0 && (
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {entries.length} items
                  </Badge>
                )}
              </h3>

              {isLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-12 w-full rounded-lg" />
                  ))}
                </div>
              ) : entries.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">
                  <div className="text-4xl mb-3">🍽️</div>
                  <p className="text-sm">
                    No meals logged for this day yet. Add your first meal above!
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {entries.map((entry: NutritionData, index: number) => (
                    <motion.div
                      key={`${entry.foodName}-${String(entry.date)}`}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-center justify-between rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors px-3 py-2.5 group"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="h-2.5 w-2.5 rounded-full flex-shrink-0"
                          style={{
                            backgroundColor:
                              CHART_COLORS[index % CHART_COLORS.length],
                          }}
                        />
                        <span className="text-sm font-medium">
                          {entry.foodName}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-bold text-primary">
                          {Number(entry.calories)} kcal
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                          onClick={() =>
                            toast.info(
                              "Delete functionality requires backend support",
                            )
                          }
                          aria-label="Remove food entry"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </div>

          {/* Right: Chart */}
          <div className="space-y-6">
            {/* Pie chart */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="rounded-xl border border-border/50 bg-card p-5"
            >
              <h3 className="font-display font-bold mb-4">Meal Breakdown</h3>
              {chartData.length > 0 ? (
                <>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={chartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={85}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {chartData.map((entry) => (
                          <Cell
                            key={`cell-${entry.name}`}
                            fill={entry.color}
                            stroke="transparent"
                          />
                        ))}
                      </Pie>
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="rounded-lg border border-border/50 bg-card px-3 py-2 shadow-xs text-sm">
                                <div className="font-medium">
                                  {payload[0].name}
                                </div>
                                <div className="text-primary">
                                  {payload[0].value} kcal
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-2 mt-3">
                    {chartData.map((item) => (
                      <div
                        key={item.name}
                        className="flex items-center justify-between text-sm"
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className="h-2.5 w-2.5 rounded-full"
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="truncate max-w-[120px]">
                            {item.name}
                          </span>
                        </div>
                        <span className="font-medium">{item.value} kcal</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <div className="text-3xl mb-2">📊</div>
                  <p className="text-sm">
                    Chart will appear once you log meals
                  </p>
                </div>
              )}
            </motion.div>

            {/* Quick add suggestions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.35 }}
              className="rounded-xl border border-border/50 bg-card p-5"
            >
              <h3 className="font-display font-bold mb-3">Quick Add</h3>
              <div className="space-y-2">
                {[
                  { name: "Idli + Sambar (3 pcs)", cal: 220 },
                  { name: "Dal Rice (1 plate)", cal: 450 },
                  { name: "Boiled Egg", cal: 78 },
                  { name: "Banana", cal: 90 },
                  { name: "Chicken Breast 100g", cal: 165 },
                  { name: "Roti (1 piece)", cal: 100 },
                ].map((item) => (
                  <button
                    key={item.name}
                    type="button"
                    className="w-full flex items-center justify-between rounded-lg bg-muted/30 hover:bg-primary/10 hover:text-primary transition-colors px-3 py-2 text-sm text-left"
                    onClick={() => {
                      setFoodName(item.name);
                      setCalories(String(item.cal));
                      foodInputRef.current?.focus();
                    }}
                  >
                    <span>{item.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {item.cal} kcal
                    </span>
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Link to diet planner */}
            <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 text-center">
              <p className="text-sm text-muted-foreground mb-3">
                Want a personalized meal plan to follow?
              </p>
              <Link to="/diet-planner">
                <Button
                  size="sm"
                  className="bg-primary text-primary-foreground gap-1.5"
                >
                  Generate Diet Plan
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
