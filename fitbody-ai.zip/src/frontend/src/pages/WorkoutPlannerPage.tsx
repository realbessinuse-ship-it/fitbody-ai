import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { FALLBACK_WORKOUTS } from "@/data/fallbackWorkouts";
import { useMetaTags } from "@/hooks/useMetaTags";
import { useWorkoutPlans } from "@/hooks/useQueries";
import {
  Calendar,
  ChevronDown,
  ChevronUp,
  Dumbbell,
  Filter,
  Flame,
  Home,
} from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import type { WorkoutPlan } from "../backend.d";

const DAYS = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];

const DIFFICULTY_COLORS: Record<string, { badge: string; dot: string }> = {
  Beginner: {
    badge: "bg-green-500/10 text-green-600 border-green-500/20",
    dot: "bg-green-500",
  },
  Intermediate: {
    badge: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
    dot: "bg-yellow-500",
  },
  Advanced: {
    badge: "bg-red-500/10 text-red-600 border-red-500/20",
    dot: "bg-red-500",
  },
};

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  Home: <Home className="h-4 w-4" />,
  Gym: <Dumbbell className="h-4 w-4" />,
};

function WorkoutCard({ plan }: { plan: WorkoutPlan }) {
  const [showSchedule, setShowSchedule] = useState(false);
  const diffColors =
    DIFFICULTY_COLORS[plan.difficulty] || DIFFICULTY_COLORS.Beginner;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-border/50 bg-card hover:border-primary/30 hover:shadow-lime-sm transition-all duration-300"
    >
      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <h3 className="font-display font-bold text-lg leading-tight">
              {plan.name}
            </h3>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge variant="outline" className="gap-1.5 text-xs">
                {CATEGORY_ICONS[plan.category]}
                {plan.category}
              </Badge>
              <Badge
                variant="outline"
                className={`text-xs ${diffColors.badge}`}
              >
                <div
                  className={`h-1.5 w-1.5 rounded-full ${diffColors.dot} mr-1.5`}
                />
                {plan.difficulty}
              </Badge>
            </div>
          </div>
          <div className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
            {CATEGORY_ICONS[plan.category] || (
              <Dumbbell className="h-5 w-5 text-primary" />
            )}
          </div>
        </div>

        {/* Weekly schedule preview */}
        <div className="flex items-center gap-1.5 mb-3">
          {plan.weeklySchedule.slice(0, 7).map((day, i) => (
            <div
              key={`${plan.id}-day-${i}`}
              className={`h-2 flex-1 rounded-full ${
                day.toLowerCase().includes("rest")
                  ? "bg-muted"
                  : "bg-primary/60"
              }`}
              title={DAYS[i]}
            />
          ))}
        </div>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
          <span>Mon</span>
          <span>Sun</span>
        </div>

        <Button
          variant="outline"
          size="sm"
          className="w-full gap-2"
          onClick={() => setShowSchedule(!showSchedule)}
        >
          <Calendar className="h-3.5 w-3.5" />
          {showSchedule ? "Hide Schedule" : "View Weekly Schedule"}
          {showSchedule ? (
            <ChevronUp className="h-3.5 w-3.5" />
          ) : (
            <ChevronDown className="h-3.5 w-3.5" />
          )}
        </Button>
      </div>

      {/* Weekly schedule detail */}
      {showSchedule && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="border-t border-border/50 p-4 space-y-2"
        >
          {plan.weeklySchedule.map((dayPlan, i) => (
            <div
              key={`${plan.id}-schedule-${i}`}
              className={`flex gap-3 rounded-lg p-2.5 ${
                dayPlan.toLowerCase().includes("rest")
                  ? "bg-muted/30"
                  : "bg-primary/5"
              }`}
            >
              <div className="flex-shrink-0 w-10 text-xs font-bold text-muted-foreground pt-0.5">
                {DAYS[i]?.slice(0, 3)}
              </div>
              <div className="text-sm leading-relaxed">
                {dayPlan.toLowerCase().includes("rest") ? (
                  <span className="text-muted-foreground">{dayPlan}</span>
                ) : (
                  <span>{dayPlan}</span>
                )}
              </div>
            </div>
          ))}
        </motion.div>
      )}
    </motion.div>
  );
}

function SkeletonCard() {
  return (
    <div className="rounded-2xl border border-border/50 bg-card p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="space-y-2 flex-1">
          <Skeleton className="h-5 w-2/3" />
          <div className="flex gap-2">
            <Skeleton className="h-5 w-16" />
            <Skeleton className="h-5 w-20" />
          </div>
        </div>
        <Skeleton className="h-10 w-10 rounded-xl" />
      </div>
      <Skeleton className="h-2 w-full rounded-full mb-4" />
      <Skeleton className="h-8 w-full" />
    </div>
  );
}

export function WorkoutPlannerPage() {
  useMetaTags({
    title: "Workout Planner",
    description:
      "Browse home and gym workout plans for all fitness levels — beginner to advanced — with weekly schedules.",
  });

  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("All");

  const { data: backendPlans, isLoading } = useWorkoutPlans();
  const plans =
    backendPlans && backendPlans.length > 0 ? backendPlans : FALLBACK_WORKOUTS;

  const filtered = plans.filter((plan) => {
    const categoryOk =
      categoryFilter === "All" || plan.category === categoryFilter;
    const diffOk =
      difficultyFilter === "All" || plan.difficulty === difficultyFilter;
    return categoryOk && diffOk;
  });

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mb-10"
        >
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            <Dumbbell className="h-3.5 w-3.5 mr-1.5" />
            Training Programs
          </Badge>
          <h1 className="font-display text-4xl lg:text-5xl font-black tracking-tight mb-4">
            Workout <span className="text-gradient-lime">Planner</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Structured training programs for home and gym, from beginner to
            advanced. Each includes a complete 7-day weekly schedule.
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-wrap gap-3 mb-8"
        >
          <div className="flex items-center gap-1.5">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground font-medium">
              Category:
            </span>
          </div>
          {["All", "Home", "Gym"].map((cat) => (
            <Button
              key={cat}
              size="sm"
              variant={categoryFilter === cat ? "default" : "outline"}
              onClick={() => setCategoryFilter(cat)}
              className={`gap-1.5 ${categoryFilter === cat ? "bg-primary text-primary-foreground" : ""}`}
            >
              {cat === "Home" && <Home className="h-3.5 w-3.5" />}
              {cat === "Gym" && <Dumbbell className="h-3.5 w-3.5" />}
              {cat}
            </Button>
          ))}

          <div className="flex items-center gap-1.5 ml-4">
            <Flame className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground font-medium">
              Level:
            </span>
          </div>
          {["All", "Beginner", "Intermediate", "Advanced"].map((diff) => (
            <Button
              key={diff}
              size="sm"
              variant={difficultyFilter === diff ? "default" : "outline"}
              onClick={() => setDifficultyFilter(diff)}
              className={`${difficultyFilter === diff ? "bg-primary text-primary-foreground" : ""}`}
            >
              {diff}
            </Button>
          ))}
        </motion.div>

        {/* Results count */}
        <div className="text-sm text-muted-foreground mb-6">
          Showing {filtered.length} of {plans.length} programs
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-5xl mb-4">🏋️</div>
            <h3 className="font-display text-xl font-bold mb-2">
              No programs found
            </h3>
            <p className="text-muted-foreground text-sm">
              Try adjusting your filters
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((plan) => (
              <WorkoutCard key={String(plan.id)} plan={plan} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
