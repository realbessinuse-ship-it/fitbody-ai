import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useInternetIdentity } from "@/hooks/useInternetIdentity";
import { useMetaTags } from "@/hooks/useMetaTags";
import {
  useDietPlan,
  useFoodEntries,
  useSaveUserProfile,
  useUserProfile,
} from "@/hooks/useQueries";
import { Link } from "@tanstack/react-router";
import {
  BookOpen,
  Brain,
  Calculator,
  Dumbbell,
  Flame,
  LayoutDashboard,
  Loader2,
  Lock,
  Save,
  TrendingUp,
  User,
  Utensils,
  Zap,
} from "lucide-react";
import { motion } from "motion/react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { UserProfile } from "../backend.d";

function LoginPrompt() {
  const { login, isLoggingIn } = useInternetIdentity();
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="inline-flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10 mb-6">
          <Lock className="h-10 w-10 text-primary" />
        </div>
        <h2 className="font-display text-2xl font-black mb-3">
          Login Required
        </h2>
        <p className="text-muted-foreground mb-6">
          Access your personal fitness dashboard. Login to view your stats and
          manage your profile.
        </p>
        <Button
          onClick={login}
          disabled={isLoggingIn}
          className="gap-2 bg-primary text-primary-foreground shadow-lime-sm"
        >
          {isLoggingIn ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <LayoutDashboard className="h-4 w-4" />
          )}
          {isLoggingIn ? "Connecting..." : "Login to Dashboard"}
        </Button>
      </div>
    </div>
  );
}

function calculateBMI(weight: number, height: number) {
  const h = height / 100;
  return Math.round((weight / (h * h)) * 10) / 10;
}

function getBMILabel(bmi: number) {
  if (bmi < 18.5) return { label: "Underweight", color: "text-blue-500" };
  if (bmi < 25) return { label: "Normal", color: "text-green-500" };
  if (bmi < 30) return { label: "Overweight", color: "text-yellow-500" };
  return { label: "Obese", color: "text-red-500" };
}

const QUICK_LINKS = [
  {
    href: "/calculators",
    icon: Calculator,
    label: "Body Calculators",
    color: "bg-chart-1/10 text-chart-1",
  },
  {
    href: "/diet-planner",
    icon: Brain,
    label: "Diet Planner",
    color: "bg-chart-2/10 text-chart-2",
  },
  {
    href: "/workout-planner",
    icon: Dumbbell,
    label: "Workout Planner",
    color: "bg-chart-3/10 text-chart-3",
  },
  {
    href: "/calorie-tracker",
    icon: TrendingUp,
    label: "Calorie Tracker",
    color: "bg-chart-4/10 text-chart-4",
  },
  {
    href: "/blog",
    icon: BookOpen,
    label: "Fitness Blog",
    color: "bg-chart-5/10 text-chart-5",
  },
];

export function DashboardPage() {
  useMetaTags({
    title: "My Dashboard",
    description:
      "Your personal FitBody AI dashboard — track progress, manage your profile, and access all fitness tools.",
  });

  const { identity } = useInternetIdentity();
  const isAuthenticated = !!identity;

  const { data: profile, isLoading: profileLoading } = useUserProfile();
  const { data: dietPlan } = useDietPlan();
  const { data: todayEntries = [] } = useFoodEntries(new Date());
  const saveProfileMutation = useSaveUserProfile();

  const [profileForm, setProfileForm] = useState<{
    age: string;
    weight: string;
    height: string;
    gender: string;
    activityLevel: string;
    fitnessGoal: string;
  }>({
    age: "",
    weight: "",
    height: "",
    gender: "male",
    activityLevel: "moderate",
    fitnessGoal: "weight-loss",
  });

  useEffect(() => {
    if (profile) {
      setProfileForm({
        age: String(Number(profile.age)),
        weight: String(Number(profile.weight)),
        height: String(Number(profile.height)),
        gender: profile.gender,
        activityLevel: profile.activityLevel,
        fitnessGoal: profile.fitnessGoal,
      });
    }
  }, [profile]);

  const handleSaveProfile = async () => {
    if (!profileForm.age || !profileForm.weight || !profileForm.height) {
      toast.error("Please fill in all required fields.");
      return;
    }

    const profileData: UserProfile = {
      age: BigInt(Number.parseInt(profileForm.age)),
      weight: BigInt(Number.parseInt(profileForm.weight)),
      height: BigInt(Number.parseInt(profileForm.height)),
      gender: profileForm.gender,
      activityLevel: profileForm.activityLevel,
      fitnessGoal: profileForm.fitnessGoal,
    };

    try {
      await saveProfileMutation.mutateAsync(profileData);
      toast.success("Profile saved successfully!");
    } catch {
      toast.error("Failed to save profile. Please try again.");
    }
  };

  const principalId = identity?.getPrincipal().toString();
  const shortId = principalId
    ? `${principalId.slice(0, 5)}...${principalId.slice(-3)}`
    : "";

  const todayCalories = todayEntries.reduce(
    (sum, e) => sum + Number(e.calories),
    0,
  );

  const bmi = profile
    ? calculateBMI(Number(profile.weight), Number(profile.height))
    : null;
  const bmiInfo = bmi ? getBMILabel(bmi) : null;

  if (!isAuthenticated) return <LoginPrompt />;

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-10"
        >
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            <Zap className="h-3.5 w-3.5 mr-1.5" />
            Personal Dashboard
          </Badge>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="font-display text-4xl lg:text-5xl font-black tracking-tight">
                Welcome back! <span className="text-gradient-lime">💪</span>
              </h1>
              <p className="text-muted-foreground mt-2">
                Principal:{" "}
                <code className="text-xs bg-muted rounded px-1.5 py-0.5">
                  {shortId}
                </code>
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats cards */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
        >
          {/* BMI */}
          <div className="rounded-xl border border-border/50 bg-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-lg bg-chart-1/10 flex items-center justify-center">
                <User className="h-4 w-4 text-chart-1" />
              </div>
              <span className="text-sm text-muted-foreground">BMI</span>
            </div>
            {profileLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : bmi ? (
              <>
                <div className="font-display text-2xl font-black">{bmi}</div>
                <div className={`text-xs mt-1 ${bmiInfo?.color}`}>
                  {bmiInfo?.label}
                </div>
              </>
            ) : (
              <div className="font-display text-2xl font-black text-muted-foreground">
                —
              </div>
            )}
          </div>

          {/* Today's Calories */}
          <div className="rounded-xl border border-border/50 bg-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-lg bg-chart-2/10 flex items-center justify-center">
                <Flame className="h-4 w-4 text-chart-2" />
              </div>
              <span className="text-sm text-muted-foreground">Today</span>
            </div>
            <div className="font-display text-2xl font-black">
              {todayCalories.toLocaleString()}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              kcal logged
            </div>
          </div>

          {/* Diet Plan */}
          <div className="rounded-xl border border-border/50 bg-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <Utensils className="h-4 w-4 text-chart-3" />
              </div>
              <span className="text-sm text-muted-foreground">Diet Plan</span>
            </div>
            <div className="font-display text-2xl font-black">
              {dietPlan ? dietPlan.meals.length : "—"}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {dietPlan ? `meals/day (${dietPlan.goalType})` : "Not set"}
            </div>
          </div>

          {/* Meals Today */}
          <div className="rounded-xl border border-border/50 bg-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-8 w-8 rounded-lg bg-chart-4/10 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-chart-4" />
              </div>
              <span className="text-sm text-muted-foreground">
                Meals Logged
              </span>
            </div>
            <div className="font-display text-2xl font-black">
              {todayEntries.length}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              meals today
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <div className="rounded-2xl border border-border/50 bg-card p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h2 className="font-display text-xl font-bold">
                    Profile Settings
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Update your fitness profile
                  </p>
                </div>
              </div>

              {profileLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="space-y-2">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-10 w-full" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Age</Label>
                      <Input
                        type="number"
                        placeholder="25"
                        value={profileForm.age}
                        onChange={(e) =>
                          setProfileForm((p) => ({ ...p, age: e.target.value }))
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Weight (kg)</Label>
                      <Input
                        type="number"
                        placeholder="70"
                        value={profileForm.weight}
                        onChange={(e) =>
                          setProfileForm((p) => ({
                            ...p,
                            weight: e.target.value,
                          }))
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Height (cm)</Label>
                      <Input
                        type="number"
                        placeholder="175"
                        value={profileForm.height}
                        onChange={(e) =>
                          setProfileForm((p) => ({
                            ...p,
                            height: e.target.value,
                          }))
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Gender</Label>
                    <Select
                      value={profileForm.gender}
                      onValueChange={(v) =>
                        setProfileForm((p) => ({ ...p, gender: v }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Activity Level</Label>
                    <Select
                      value={profileForm.activityLevel}
                      onValueChange={(v) =>
                        setProfileForm((p) => ({ ...p, activityLevel: v }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedentary">Sedentary</SelectItem>
                        <SelectItem value="light">Lightly Active</SelectItem>
                        <SelectItem value="moderate">
                          Moderately Active
                        </SelectItem>
                        <SelectItem value="active">Very Active</SelectItem>
                        <SelectItem value="very-active">
                          Extremely Active
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Fitness Goal</Label>
                    <Select
                      value={profileForm.fitnessGoal}
                      onValueChange={(v) =>
                        setProfileForm((p) => ({ ...p, fitnessGoal: v }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weight-loss">Weight Loss</SelectItem>
                        <SelectItem value="weight-gain">Weight Gain</SelectItem>
                        <SelectItem value="muscle-gain">Muscle Gain</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="performance">
                          Athletic Performance
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <Button
                    onClick={handleSaveProfile}
                    disabled={saveProfileMutation.isPending}
                    className="w-full gap-2 bg-primary text-primary-foreground shadow-lime-sm"
                  >
                    {saveProfileMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    {saveProfileMutation.isPending
                      ? "Saving..."
                      : "Save Profile"}
                  </Button>
                </div>
              )}
            </div>
          </motion.div>

          {/* Right Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Quick Links */}
            <div className="rounded-2xl border border-border/50 bg-card p-5">
              <h3 className="font-display font-bold mb-4">Quick Access</h3>
              <div className="space-y-2">
                {QUICK_LINKS.map((link) => (
                  <Link key={link.href} to={link.href}>
                    <div className="flex items-center gap-3 rounded-lg hover:bg-muted/50 transition-colors p-2.5 group cursor-pointer">
                      <div
                        className={`h-8 w-8 rounded-lg ${link.color} flex items-center justify-center`}
                      >
                        <link.icon className="h-4 w-4" />
                      </div>
                      <span className="text-sm font-medium group-hover:text-primary transition-colors">
                        {link.label}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Diet Plan Summary */}
            {dietPlan && (
              <div className="rounded-2xl border border-border/50 bg-card p-5">
                <h3 className="font-display font-bold mb-3">
                  Current Diet Plan
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Goal</span>
                    <Badge variant="secondary" className="text-xs capitalize">
                      {dietPlan.goalType.replace("-", " ")}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Diet Type</span>
                    <span className="font-medium text-xs">
                      {dietPlan.dietPreference}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Meals/Day</span>
                    <span className="font-medium">{dietPlan.meals.length}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Total kcal</span>
                    <span className="font-bold text-primary">
                      {dietPlan.meals
                        .reduce(
                          (s, m) =>
                            s +
                            m.foods.reduce(
                              (fs, f) => fs + Number(f.calories),
                              0,
                            ),
                          0,
                        )
                        .toLocaleString()}{" "}
                      kcal
                    </span>
                  </div>
                </div>
                <Link to="/diet-planner">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-3 gap-1.5"
                  >
                    <Utensils className="h-3.5 w-3.5" />
                    View Full Plan
                  </Button>
                </Link>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
