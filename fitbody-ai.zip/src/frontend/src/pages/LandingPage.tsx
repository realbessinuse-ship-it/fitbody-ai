import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useMetaTags } from "@/hooks/useMetaTags";
import { Link } from "@tanstack/react-router";
import {
  Activity,
  ArrowRight,
  Brain,
  Calculator,
  Dumbbell,
  Star,
  Target,
  TrendingUp,
  Utensils,
  Zap,
} from "lucide-react";
import { type Variants, motion } from "motion/react";

const FEATURES = [
  {
    icon: Calculator,
    title: "Body Calculators",
    description:
      "BMI, BMR, body fat %, ideal weight, and daily calorie needs — scientifically validated.",
    href: "/calculators",
    accentColor: "oklch(0.83 0.24 130)",
    accentBg: "bg-primary/8 dark:bg-primary/12",
    accentText: "text-primary",
    tag: "5 tools",
  },
  {
    icon: Brain,
    title: "AI Diet Planner",
    description:
      "Personalized Indian & international meal plans tuned to your goals and body metrics.",
    href: "/diet-planner",
    accentColor: "oklch(0.72 0.25 26)",
    accentBg: "bg-chart-2/8 dark:bg-chart-2/12",
    accentText: "text-chart-2",
    tag: "8 plan types",
  },
  {
    icon: Dumbbell,
    title: "Workout Planner",
    description:
      "Home & gym programs from beginner to advanced, with full 7-day weekly schedules.",
    href: "/workout-planner",
    accentColor: "oklch(0.56 0.21 265)",
    accentBg: "bg-chart-3/8 dark:bg-chart-3/12",
    accentText: "text-chart-3",
    tag: "6 programs",
  },
  {
    icon: TrendingUp,
    title: "Calorie Tracker",
    description:
      "Log every meal, visualize daily macros, and stay on track with your nutrition goals.",
    href: "/calorie-tracker",
    accentColor: "oklch(0.65 0.19 180)",
    accentBg: "bg-chart-4/8 dark:bg-chart-4/12",
    accentText: "text-chart-4",
    tag: "daily logging",
  },
  {
    icon: Target,
    title: "Personal Dashboard",
    description:
      "Your fitness hub — stats, progress history, saved plans, and all tools in one view.",
    href: "/dashboard",
    accentColor: "oklch(0.73 0.17 52)",
    accentBg: "bg-chart-5/8 dark:bg-chart-5/12",
    accentText: "text-chart-5",
    tag: "personalized",
  },
  {
    icon: Activity,
    title: "Fitness Blog",
    description:
      "Expert-backed articles on nutrition, training, recovery, and building lasting habits.",
    href: "/blog",
    accentColor: "oklch(0.83 0.24 130)",
    accentBg: "bg-primary/8 dark:bg-primary/12",
    accentText: "text-primary",
    tag: "6+ articles",
  },
];

const STATS = [
  { value: "5+", label: "Calculators" },
  { value: "8+", label: "Diet Plans" },
  { value: "6+", label: "Workouts" },
  { value: "100%", label: "AI-Powered" },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.09,
    },
  },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] },
  },
};

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
  },
};

export function LandingPage() {
  useMetaTags({
    title: "Train Smarter. Eat Better. Live Stronger.",
    description:
      "FitBody AI — your complete AI-powered fitness platform. Get personalized diet plans, workout programs, and body analytics.",
    ogImage: "/assets/generated/hero-fitness-v2.dim_1600x900.jpg",
  });

  return (
    <div className="min-h-screen">
      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative min-h-[96vh] flex items-center overflow-hidden">
        {/* Background layers */}
        <div className="absolute inset-0 bg-hero-dark" />

        {/* Grid overlay */}
        <div className="absolute inset-0 bg-grid-pattern opacity-100" />

        {/* Hero image — right-aligned, cinematic */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('/assets/generated/hero-fitness-v2.dim_1600x900.jpg')",
            backgroundPosition: "65% center",
          }}
        />
        {/* Heavy left-side fade to keep text readable */}
        <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.07_0.014_255)] via-[oklch(0.07_0.014_255/0.88)] to-[oklch(0.07_0.014_255/0.15)]" />
        {/* Bottom fade into content */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[oklch(0.09_0.012_255)]" />

        {/* Lime accent line — left edge */}
        <div className="absolute left-0 top-1/4 bottom-1/4 w-0.5 bg-gradient-to-b from-transparent via-primary to-transparent opacity-60" />

        {/* Content */}
        <div className="container relative mx-auto px-4 py-28">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="max-w-3xl"
          >
            {/* Badge */}
            <motion.div variants={itemVariants}>
              <Badge className="mb-7 gap-2 px-4 py-1.5 text-sm bg-primary/15 text-primary border-primary/30 font-medium tracking-wide uppercase text-[11px]">
                <Zap className="h-3 w-3 fill-current" />
                AI-Powered Fitness Platform
              </Badge>
            </motion.div>

            {/* Headline */}
            <motion.h1
              variants={itemVariants}
              className="font-display text-[clamp(2.8rem,8vw,5.5rem)] font-black leading-[0.92] tracking-tight mb-7 text-white"
            >
              Train Smarter.{" "}
              <span className="text-gradient-lime">Eat Better.</span>
              <br />
              Live Stronger.
            </motion.h1>

            {/* Sub */}
            <motion.p
              variants={itemVariants}
              className="text-lg sm:text-xl text-white/60 max-w-xl leading-relaxed mb-10 font-light"
            >
              Your complete AI fitness companion — personalized diet plans,
              intelligent workouts, body analytics, and calorie tracking in one
              platform.
            </motion.p>

            {/* CTAs */}
            <motion.div
              variants={itemVariants}
              className="flex flex-wrap gap-3"
            >
              <Link to="/diet-planner">
                <Button
                  size="lg"
                  className="gap-2.5 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lime-md text-base px-8 h-13 font-semibold rounded-xl transition-all duration-200 hover:shadow-lime-lg hover:-translate-y-0.5"
                >
                  <Brain className="h-5 w-5" />
                  Generate My Diet Plan
                  <ArrowRight className="h-4 w-4 ml-0.5" />
                </Button>
              </Link>
              <Link to="/calculators">
                <Button
                  size="lg"
                  variant="outline"
                  className="gap-2 text-base px-7 h-13 border-white/20 text-white hover:border-primary/50 hover:text-primary hover:bg-primary/5 rounded-xl transition-all duration-200"
                >
                  <Calculator className="h-5 w-5" />
                  Body Calculators
                </Button>
              </Link>
            </motion.div>

            {/* Stats row */}
            <motion.div
              variants={containerVariants}
              className="flex flex-wrap gap-x-10 gap-y-4 mt-16 pt-10 border-t border-white/10"
            >
              {STATS.map((stat) => (
                <motion.div
                  key={stat.label}
                  variants={itemVariants}
                  className="flex flex-col gap-1"
                >
                  <div className="stat-number text-[2.2rem] text-gradient-lime">
                    {stat.value}
                  </div>
                  <div className="text-xs text-white/50 font-medium uppercase tracking-widest">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>

        {/* Floating tool pills — right side decoration (desktop) */}
        <div className="hidden xl:flex absolute right-12 top-1/2 -translate-y-1/2 flex-col gap-3 opacity-60">
          {[
            { icon: "🔥", label: "TDEE Calculator" },
            { icon: "💪", label: "Workout Plans" },
            { icon: "🥗", label: "Diet Generator" },
            { icon: "📊", label: "Body Analytics" },
          ].map((pill, i) => (
            <motion.div
              key={pill.label}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + i * 0.12, duration: 0.4 }}
              className="flex items-center gap-2.5 bg-white/6 backdrop-blur-sm border border-white/10 rounded-full px-4 py-2 text-sm text-white/70 font-medium"
            >
              <span>{pill.icon}</span>
              {pill.label}
            </motion.div>
          ))}
        </div>
      </section>

      {/* ── Features ─────────────────────────────────────────────────────── */}
      <section className="py-28 bg-background relative overflow-hidden">
        {/* Subtle grid */}
        <div className="absolute inset-0 bg-grid-pattern opacity-50" />

        <div className="container relative mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="mb-16"
          >
            <Badge className="mb-5 gap-1.5 bg-primary/10 text-primary border-primary/20 font-medium uppercase tracking-wide text-[11px]">
              <Star className="h-3 w-3 fill-current" />
              Everything You Need
            </Badge>
            <h2 className="font-display text-4xl lg:text-[3.25rem] font-black tracking-tight mb-5 max-w-xl">
              Your Complete{" "}
              <span className="text-gradient-lime">Fitness Toolkit</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
              Six powerful tools working together to help you achieve your
              fitness goals faster than ever.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5"
          >
            {FEATURES.map((feature, i) => (
              <motion.div key={feature.href} variants={cardVariants} custom={i}>
                <Link to={feature.href} className="block h-full group">
                  <div className="relative h-full p-6 rounded-2xl border border-border/60 bg-card card-elevated hover:border-primary/40 hover:-translate-y-1 hover:shadow-lime-sm transition-all duration-250 cursor-pointer overflow-hidden">
                    {/* Diagonal accent in corner */}
                    <div
                      className="absolute top-0 right-0 w-20 h-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{
                        background: `radial-gradient(circle at 100% 0%, ${feature.accentColor}18 0%, transparent 70%)`,
                      }}
                    />

                    {/* Icon */}
                    <div
                      className={`inline-flex h-11 w-11 items-center justify-center rounded-xl ${feature.accentBg} mb-5 group-hover:scale-110 transition-transform duration-200`}
                    >
                      <feature.icon
                        className={`h-5 w-5 ${feature.accentText}`}
                      />
                    </div>

                    {/* Tag pill */}
                    <div
                      className={`inline-flex items-center text-[10px] font-semibold uppercase tracking-wider ${feature.accentText} opacity-60 mb-2.5 ml-2`}
                    >
                      {feature.tag}
                    </div>

                    <h3 className="font-display font-black text-[1.1rem] mb-2.5 group-hover:text-primary transition-colors duration-150">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>

                    {/* Hover CTA */}
                    <div className="mt-5 flex items-center gap-1.5 text-sm font-semibold text-primary translate-x-0 group-hover:translate-x-0.5 opacity-0 group-hover:opacity-100 transition-all duration-200">
                      Explore
                      <ArrowRight className="h-3.5 w-3.5" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Social proof / Why FitBody AI ────────────────────────────────── */}
      <section className="py-20 bg-muted/30 border-y border-border/40">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center"
          >
            {[
              {
                icon: "🎯",
                value: "5+",
                label: "Body Calculators",
                sub: "Evidence-based",
              },
              {
                icon: "🥗",
                value: "8+",
                label: "Diet Plan Types",
                sub: "Indian & International",
              },
              {
                icon: "🏋️",
                value: "6+",
                label: "Workout Programs",
                sub: "All skill levels",
              },
              {
                icon: "🤖",
                value: "AI",
                label: "Powered Plans",
                sub: "Personalised for you",
              },
            ].map((item) => (
              <div
                key={item.label}
                className="flex flex-col items-center gap-2"
              >
                <span className="text-3xl mb-1">{item.icon}</span>
                <div className="stat-number text-4xl text-gradient-lime">
                  {item.value}
                </div>
                <div className="font-display font-bold text-sm">
                  {item.label}
                </div>
                <div className="text-xs text-muted-foreground">{item.sub}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── CTA Section ──────────────────────────────────────────────────── */}
      <section className="py-28 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="relative overflow-hidden rounded-3xl bg-hero-dark border border-white/8 p-14 text-center"
          >
            {/* Grid overlay */}
            <div className="absolute inset-0 bg-grid-pattern opacity-40" />

            {/* Top lime accent line */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />

            {/* Corner lime glows */}
            <div className="absolute top-0 left-0 w-64 h-64 bg-primary/5 blur-3xl rounded-full -translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 right-0 w-64 h-64 bg-energy/5 blur-3xl rounded-full translate-x-1/2 translate-y-1/2" />

            <div className="relative">
              <Badge className="mb-6 gap-1.5 bg-primary/15 text-primary border-primary/30 uppercase tracking-wide text-[11px] font-semibold">
                <Zap className="h-3 w-3 fill-current" />
                Start Free Today
              </Badge>
              <h2 className="font-display text-4xl lg:text-[3.25rem] font-black tracking-tight mb-5 text-white">
                Ready to <span className="text-gradient-energy">Transform</span>{" "}
                Your Body?
              </h2>
              <p className="text-lg text-white/55 max-w-xl mx-auto mb-10 font-light leading-relaxed">
                Start with a personalized AI diet plan — just enter your details
                and get a complete 6-meal plan tailored to your goals in
                seconds.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Link to="/diet-planner">
                  <Button
                    size="lg"
                    className="gap-2.5 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lime-md text-base px-9 h-13 font-semibold rounded-xl hover:shadow-lime-lg hover:-translate-y-0.5 transition-all duration-200"
                  >
                    <Brain className="h-5 w-5" />
                    Create My Diet Plan
                  </Button>
                </Link>
                <Link to="/workout-planner">
                  <Button
                    size="lg"
                    variant="outline"
                    className="gap-2 text-base px-7 h-13 border-white/20 text-white hover:border-primary/50 hover:text-primary hover:bg-primary/5 rounded-xl transition-all duration-200"
                  >
                    <Dumbbell className="h-5 w-5" />
                    View Workouts
                  </Button>
                </Link>
              </div>

              {/* Tool chips row */}
              <div className="mt-12 flex flex-wrap justify-center gap-2.5">
                {[
                  {
                    icon: <Calculator className="h-3 w-3" />,
                    label: "BMI Calculator",
                  },
                  {
                    icon: <Brain className="h-3 w-3" />,
                    label: "Diet Planner",
                  },
                  {
                    icon: <Dumbbell className="h-3 w-3" />,
                    label: "Workout Plans",
                  },
                  {
                    icon: <TrendingUp className="h-3 w-3" />,
                    label: "Calorie Tracker",
                  },
                  {
                    icon: <Utensils className="h-3 w-3" />,
                    label: "Meal Logging",
                  },
                  {
                    icon: <Activity className="h-3 w-3" />,
                    label: "Progress Tracking",
                  },
                ].map((chip) => (
                  <div
                    key={chip.label}
                    className="flex items-center gap-1.5 bg-white/6 border border-white/10 rounded-full px-3.5 py-1.5 text-xs text-white/60 font-medium"
                  >
                    <span className="text-primary">{chip.icon}</span>
                    {chip.label}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
