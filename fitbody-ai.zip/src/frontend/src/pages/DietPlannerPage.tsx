import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useInternetIdentity } from "@/hooks/useInternetIdentity";
import { useMetaTags } from "@/hooks/useMetaTags";
import { useDietPlan, useSaveDietPlan } from "@/hooks/useQueries";
import {
  Brain,
  ChevronDown,
  ChevronUp,
  Flame,
  Loader2,
  RefreshCw,
  Save,
  Utensils,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { DietPlan, FoodItem, MealData } from "../backend.d";

// ─── Diet Generation Logic ────────────────────────────────────────────────────

interface DietInputs {
  age: number;
  height: number;
  weight: number;
  gender: string;
  activityLevel: string;
  goal: string;
  dietType: string;
}

const MEAL_NAMES = [
  "Breakfast",
  "Mid-Morning Snack",
  "Lunch",
  "Evening Snack",
  "Dinner",
  "Post-Workout",
];

type FoodDB = Record<string, Record<string, { name: string; cal: number }[]>>;

const FOOD_DB: FoodDB = {
  "Indian Veg": {
    Breakfast: [
      { name: "Idli (3 pieces) with sambar", cal: 220 },
      { name: "Poha with peanuts", cal: 250 },
      { name: "Upma with vegetables", cal: 200 },
      { name: "Paratha with curd", cal: 320 },
      { name: "Dalia (broken wheat) porridge", cal: 180 },
    ],
    "Mid-Morning Snack": [
      { name: "Mixed fruit bowl (banana, apple, papaya)", cal: 150 },
      { name: "Roasted chana (50g)", cal: 180 },
      { name: "Paneer cubes (100g)", cal: 265 },
      { name: "Sprouts salad with lemon", cal: 120 },
    ],
    Lunch: [
      { name: "2 roti + dal tadka + sabzi", cal: 450 },
      { name: "Brown rice + rajma curry + salad", cal: 500 },
      { name: "Chole with 2 chapati + raita", cal: 480 },
      { name: "Paneer curry + 2 roti + dal", cal: 520 },
    ],
    "Evening Snack": [
      { name: "Green tea + roasted makhana (30g)", cal: 110 },
      { name: "Masala chaas (buttermilk)", cal: 60 },
      { name: "Fruit smoothie (banana + milk)", cal: 200 },
      { name: "Moong dal chilla (2 pieces)", cal: 180 },
    ],
    Dinner: [
      { name: "2 roti + mixed dal + sabzi + curd", cal: 420 },
      { name: "Brown rice + palak paneer + salad", cal: 460 },
      { name: "Khichdi with ghee + raita", cal: 380 },
      { name: "Ragi dosa (2) + coconut chutney + sambar", cal: 350 },
    ],
    "Post-Workout": [
      { name: "Banana + milk protein shake", cal: 280 },
      { name: "Curd with honey and nuts", cal: 220 },
      { name: "Sattu shake (jaggery + water)", cal: 180 },
    ],
  },
  "Indian Non-Veg": {
    Breakfast: [
      { name: "4 boiled eggs + 2 roti + chai", cal: 480 },
      { name: "Egg bhurji (3 eggs) + toast", cal: 380 },
      { name: "Omelette + paratha", cal: 420 },
      { name: "Chicken sandwich + green chutney", cal: 350 },
    ],
    "Mid-Morning Snack": [
      { name: "2 boiled eggs + fruits", cal: 220 },
      { name: "Grilled chicken strips (100g)", cal: 165 },
      { name: "Tuna salad sandwich", cal: 280 },
    ],
    Lunch: [
      { name: "Chicken curry + 2 roti + dal + salad", cal: 580 },
      { name: "Fish curry + rice + sabzi", cal: 520 },
      { name: "Mutton rogan josh + 2 roti + raita", cal: 620 },
      { name: "Grilled chicken + brown rice + dal", cal: 550 },
    ],
    "Evening Snack": [
      { name: "Chicken tikka (4 pieces)", cal: 200 },
      { name: "Boiled eggs (2) + masala chai", cal: 180 },
      { name: "Fish cutlet (2 pieces)", cal: 240 },
    ],
    Dinner: [
      { name: "Grilled fish + 2 roti + dal + salad", cal: 460 },
      { name: "Chicken biryani (1.5 cups) + raita", cal: 520 },
      { name: "Egg curry + roti + vegetable sabzi", cal: 440 },
      { name: "Tandoori chicken (200g) + dal + roti", cal: 500 },
    ],
    "Post-Workout": [
      { name: "Whey protein shake + banana", cal: 280 },
      { name: "Boiled eggs (3) + milk", cal: 320 },
      { name: "Chicken breast (150g) + rice", cal: 350 },
    ],
  },
  International: {
    Breakfast: [
      { name: "Oatmeal with berries and honey", cal: 300 },
      { name: "Greek yogurt parfait with granola", cal: 380 },
      { name: "Scrambled eggs + whole grain toast + avocado", cal: 420 },
      { name: "Protein pancakes with maple syrup", cal: 450 },
    ],
    "Mid-Morning Snack": [
      { name: "Apple + almond butter (2 tbsp)", cal: 200 },
      { name: "Protein bar", cal: 220 },
      { name: "Mixed nuts (30g) + cheese", cal: 240 },
    ],
    Lunch: [
      { name: "Grilled chicken salad with quinoa", cal: 480 },
      { name: "Tuna sandwich + mixed greens", cal: 420 },
      { name: "Turkey wrap + vegetable soup", cal: 500 },
      { name: "Salmon rice bowl with vegetables", cal: 550 },
    ],
    "Evening Snack": [
      { name: "Hummus with carrot sticks + whole grain crackers", cal: 180 },
      { name: "Cottage cheese with pineapple", cal: 160 },
      { name: "Edamame (1 cup)", cal: 190 },
    ],
    Dinner: [
      { name: "Grilled salmon + sweet potato + broccoli", cal: 520 },
      { name: "Chicken stir-fry with brown rice", cal: 480 },
      { name: "Turkey meatballs + zucchini pasta", cal: 440 },
      { name: "Tofu scramble + roasted vegetables + quinoa", cal: 400 },
    ],
    "Post-Workout": [
      { name: "Whey protein shake + banana", cal: 280 },
      { name: "Chocolate milk (1 cup) + rice cakes", cal: 300 },
      { name: "Greek yogurt + granola + honey", cal: 320 },
    ],
  },
};

function generateDietPlan(inputs: DietInputs): DietPlan {
  const { gender, activityLevel, goal, dietType } = inputs;
  const w = inputs.weight;
  const h = inputs.height;
  const a = inputs.age;

  const bmr =
    gender === "male"
      ? 10 * w + 6.25 * h - 5 * a + 5
      : 10 * w + 6.25 * h - 5 * a - 161;

  const activityMultipliers: Record<string, number> = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    "very-active": 1.9,
  };

  // TDEE used for meal portion scaling; gym/muscle goals get 6 meals instead of 5
  void (bmr * (activityMultipliers[activityLevel] || 1.55));

  const isGymUser = goal === "gym" || goal === "muscle-gain";
  const mealNames = isGymUser ? MEAL_NAMES : MEAL_NAMES.slice(0, 5);

  const db = FOOD_DB[dietType] || FOOD_DB["Indian Veg"];
  const meals: MealData[] = mealNames.map((mealType) => {
    const options = db[mealType] || db.Breakfast;
    const selected = options[Math.floor(Math.random() * options.length)];
    return {
      mealType,
      foods: [{ name: selected.name, calories: BigInt(selected.cal) }],
    };
  });

  return {
    meals,
    goalType: goal,
    dietPreference: dietType,
  };
}

// ─── Meal Card Component ──────────────────────────────────────────────────────

function MealCard({ meal, index }: { meal: MealData; index: number }) {
  const [expanded, setExpanded] = useState(true);
  const totalCal = meal.foods.reduce((s, f) => s + Number(f.calories), 0);

  const mealIcons: Record<string, string> = {
    Breakfast: "🌅",
    "Mid-Morning Snack": "🍎",
    Lunch: "🍱",
    "Evening Snack": "☕",
    Dinner: "🌙",
    "Post-Workout": "💪",
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.08 }}
      className="rounded-xl border border-border/50 bg-card overflow-hidden"
    >
      <button
        type="button"
        className="w-full flex items-center justify-between p-4 hover:bg-muted/30 transition-colors text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-3">
          <span className="text-2xl">{mealIcons[meal.mealType] || "🍽️"}</span>
          <div>
            <div className="font-display font-bold">{meal.mealType}</div>
            <div className="text-sm text-muted-foreground">{totalCal} kcal</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {meal.foods.length} item{meal.foods.length !== 1 ? "s" : ""}
          </Badge>
          {expanded ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-border/50"
          >
            <div className="p-4 space-y-2">
              {meal.foods.map((food: FoodItem, fi: number) => (
                <div
                  key={`${food.name}-${fi}`}
                  className="flex items-center justify-between rounded-lg bg-muted/30 px-3 py-2"
                >
                  <span className="text-sm">{food.name}</span>
                  <span className="text-sm font-medium text-primary">
                    {Number(food.calories)} kcal
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export function DietPlannerPage() {
  useMetaTags({
    title: "AI Diet Planner",
    description:
      "Generate a personalized Indian or international diet plan based on your goals, body metrics, and preferences.",
  });

  const { identity } = useInternetIdentity();
  const isAuthenticated = !!identity;

  const { data: savedPlan } = useDietPlan();
  const saveDietPlanMutation = useSaveDietPlan();

  const [inputs, setInputs] = useState({
    age: "",
    height: "",
    weight: "",
    gender: "male",
    activityLevel: "moderate",
    goal: "weight-loss",
    dietType: "Indian Veg",
  });

  const [generatedPlan, setGeneratedPlan] = useState<DietPlan | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (savedPlan) {
      setGeneratedPlan(savedPlan);
    }
  }, [savedPlan]);

  const totalCalories = generatedPlan
    ? generatedPlan.meals.reduce(
        (sum, meal) =>
          sum + meal.foods.reduce((s, f) => s + Number(f.calories), 0),
        0,
      )
    : 0;

  const handleGenerate = async () => {
    if (!inputs.age || !inputs.height || !inputs.weight) {
      toast.error("Please fill in your age, height, and weight.");
      return;
    }
    setIsGenerating(true);
    await new Promise((r) => setTimeout(r, 800));
    const plan = generateDietPlan({
      age: Number.parseFloat(inputs.age),
      height: Number.parseFloat(inputs.height),
      weight: Number.parseFloat(inputs.weight),
      gender: inputs.gender,
      activityLevel: inputs.activityLevel,
      goal: inputs.goal,
      dietType: inputs.dietType,
    });
    setGeneratedPlan(plan);
    setIsGenerating(false);
  };

  const handleSave = async () => {
    if (!generatedPlan) return;
    if (!isAuthenticated) {
      toast.error("Please login to save your diet plan.");
      return;
    }
    try {
      await saveDietPlanMutation.mutateAsync(generatedPlan);
      toast.success("Diet plan saved successfully!");
    } catch {
      toast.error("Failed to save diet plan. Please try again.");
    }
  };

  const goalLabels: Record<string, string> = {
    "weight-loss": "Weight Loss",
    "weight-gain": "Weight Gain",
    "muscle-gain": "Muscle Gain",
    office: "Office Worker",
    gym: "Gym User",
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl mb-10"
        >
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            <Brain className="h-3.5 w-3.5 mr-1.5" />
            AI-Powered
          </Badge>
          <h1 className="font-display text-4xl lg:text-5xl font-black tracking-tight mb-4">
            Diet <span className="text-gradient-lime">Planner</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            Get a personalized meal plan based on your body metrics, goals, and
            food preferences.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="rounded-2xl border border-border/50 bg-card p-6 h-fit"
          >
            <h2 className="font-display text-xl font-bold mb-6">
              Your Details
            </h2>
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Age</Label>
                  <Input
                    type="number"
                    placeholder="25"
                    value={inputs.age}
                    onChange={(e) =>
                      setInputs((p) => ({ ...p, age: e.target.value }))
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Height (cm)</Label>
                  <Input
                    type="number"
                    placeholder="175"
                    value={inputs.height}
                    onChange={(e) =>
                      setInputs((p) => ({ ...p, height: e.target.value }))
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Weight (kg)</Label>
                  <Input
                    type="number"
                    placeholder="70"
                    value={inputs.weight}
                    onChange={(e) =>
                      setInputs((p) => ({ ...p, weight: e.target.value }))
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Gender</Label>
                <Select
                  value={inputs.gender}
                  onValueChange={(v) => setInputs((p) => ({ ...p, gender: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Activity Level</Label>
                <Select
                  value={inputs.activityLevel}
                  onValueChange={(v) =>
                    setInputs((p) => ({ ...p, activityLevel: v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">
                      Sedentary (desk job, no exercise)
                    </SelectItem>
                    <SelectItem value="light">
                      Lightly Active (1-3 days/week)
                    </SelectItem>
                    <SelectItem value="moderate">
                      Moderately Active (3-5 days/week)
                    </SelectItem>
                    <SelectItem value="active">
                      Very Active (6-7 days/week)
                    </SelectItem>
                    <SelectItem value="very-active">
                      Extremely Active (athlete/manual work)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Your Goal</Label>
                <Select
                  value={inputs.goal}
                  onValueChange={(v) => setInputs((p) => ({ ...p, goal: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weight-loss">Weight Loss</SelectItem>
                    <SelectItem value="weight-gain">Weight Gain</SelectItem>
                    <SelectItem value="muscle-gain">Muscle Gain</SelectItem>
                    <SelectItem value="office">
                      Office Worker (maintain)
                    </SelectItem>
                    <SelectItem value="gym">Gym User (performance)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Diet Preference</Label>
                <Select
                  value={inputs.dietType}
                  onValueChange={(v) =>
                    setInputs((p) => ({ ...p, dietType: v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Indian Veg">
                      Indian Vegetarian 🇮🇳
                    </SelectItem>
                    <SelectItem value="Indian Non-Veg">
                      Indian Non-Vegetarian 🇮🇳
                    </SelectItem>
                    <SelectItem value="International">
                      International 🌍
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="w-full h-12 text-base gap-2 bg-primary text-primary-foreground shadow-lime-sm"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Generating Plan...
                  </>
                ) : (
                  <>
                    <Brain className="h-5 w-5" />
                    {generatedPlan
                      ? "Regenerate Plan"
                      : "Generate My Diet Plan"}
                  </>
                )}
              </Button>
            </div>
          </motion.div>

          {/* Results */}
          <div className="space-y-4">
            <AnimatePresence mode="wait">
              {!generatedPlan && !isGenerating && (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="rounded-2xl border border-dashed border-border/50 bg-card/50 p-12 text-center"
                >
                  <div className="text-5xl mb-4">🍽️</div>
                  <h3 className="font-display text-xl font-bold mb-2">
                    Your plan will appear here
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Fill in your details and click "Generate" to get your
                    personalized diet plan.
                  </p>
                </motion.div>
              )}

              {isGenerating && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="rounded-2xl border border-border/50 bg-card p-12 text-center"
                >
                  <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
                    <Loader2 className="h-8 w-8 text-primary animate-spin" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">
                    Crafting your plan...
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Calculating your TDEE and selecting the best foods for your
                    goals.
                  </p>
                </motion.div>
              )}

              {generatedPlan && !isGenerating && (
                <motion.div
                  key="plan"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4"
                >
                  {/* Plan header */}
                  <div className="rounded-xl border border-primary/30 bg-primary/5 p-4">
                    <div className="flex items-center justify-between flex-wrap gap-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Flame className="h-4 w-4 text-primary" />
                          <span className="font-display font-bold text-xl">
                            {totalCalories.toLocaleString()} kcal/day
                          </span>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="secondary">
                            {goalLabels[generatedPlan.goalType] ||
                              generatedPlan.goalType}
                          </Badge>
                          <Badge variant="outline">
                            {generatedPlan.dietPreference}
                          </Badge>
                          <Badge variant="outline">
                            {generatedPlan.meals.length} meals
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleGenerate}
                          className="gap-1.5"
                        >
                          <RefreshCw className="h-3.5 w-3.5" />
                          Regenerate
                        </Button>
                        {isAuthenticated && (
                          <Button
                            size="sm"
                            onClick={handleSave}
                            disabled={saveDietPlanMutation.isPending}
                            className="gap-1.5 bg-primary text-primary-foreground"
                          >
                            {saveDietPlanMutation.isPending ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Save className="h-3.5 w-3.5" />
                            )}
                            Save Plan
                          </Button>
                        )}
                      </div>
                    </div>
                    <Progress
                      value={Math.min((totalCalories / 2500) * 100, 100)}
                      className="mt-3 h-1.5"
                    />
                  </div>

                  {/* Meals */}
                  <div className="space-y-3">
                    {generatedPlan.meals.map((meal, i) => (
                      <MealCard
                        key={`${meal.mealType}-${i}`}
                        meal={meal}
                        index={i}
                      />
                    ))}
                  </div>

                  {!isAuthenticated && (
                    <div className="rounded-lg border border-border/50 bg-muted/30 p-3 text-center text-sm text-muted-foreground">
                      <Utensils className="h-4 w-4 inline mr-1.5" />
                      Login to save this plan to your profile
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
