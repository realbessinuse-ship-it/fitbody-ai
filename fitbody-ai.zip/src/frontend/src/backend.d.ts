import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface NutritionData {
    date: Time;
    calories: bigint;
    foodName: string;
}
export interface WorkoutPlan {
    id: bigint;
    weeklySchedule: Array<string>;
    difficulty: string;
    name: string;
    category: string;
}
export interface BlogPost {
    id: bigint;
    title: string;
    body: string;
    publishedDate: Time;
    author: string;
    category: string;
}
export type Time = bigint;
export interface DietPlan {
    meals: Array<MealData>;
    goalType: string;
    dietPreference: string;
}
export interface MealData {
    foods: Array<FoodItem>;
    mealType: string;
}
export interface FoodItem {
    calories: bigint;
    name: string;
}
export interface UserProfile {
    age: bigint;
    weight: bigint;
    height: bigint;
    activityLevel: string;
    fitnessGoal: string;
    gender: string;
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    addBlogPost(title: string, body: string, category: string, author: string): Promise<void>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    getAllBlogPosts(): Promise<Array<BlogPost>>;
    getAllWorkoutPlans(): Promise<Array<WorkoutPlan>>;
    getBlogPostsByCategory(category: string): Promise<Array<BlogPost>>;
    getCallerDietPlan(): Promise<DietPlan | null>;
    getCallerUserProfile(): Promise<UserProfile | null>;
    getCallerUserRole(): Promise<UserRole>;
    getEntriesByDate(date: Time): Promise<Array<NutritionData>>;
    getUserProfile(user: Principal): Promise<UserProfile | null>;
    getWorkoutPlansByCategory(category: string): Promise<Array<WorkoutPlan>>;
    getWorkoutPlansByDifficulty(difficulty: string): Promise<Array<WorkoutPlan>>;
    isCallerAdmin(): Promise<boolean>;
    logFoodEntry(foodName: string, calories: bigint, date: Time): Promise<void>;
    saveCallerUserProfile(profile: UserProfile): Promise<void>;
    saveDietPlan(plan: DietPlan): Promise<void>;
}
