import typography from "@tailwindcss/typography";
import containerQueries from "@tailwindcss/container-queries";
import animate from "tailwindcss-animate";

/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["index.html", "src/**/*.{js,ts,jsx,tsx,html,css}"],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      fontFamily: {
        display: ['"Cabinet Grotesk"', "sans-serif"],
        body: ["Outfit", "sans-serif"],
        bricolage: ['"Bricolage Grotesque"', "sans-serif"],
        mona: ['"Mona Sans"', "sans-serif"],
      },
      colors: {
        border: "oklch(var(--border))",
        input: "oklch(var(--input))",
        ring: "oklch(var(--ring) / <alpha-value>)",
        background: "oklch(var(--background))",
        foreground: "oklch(var(--foreground))",
        primary: {
          DEFAULT: "oklch(var(--primary) / <alpha-value>)",
          foreground: "oklch(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "oklch(var(--secondary) / <alpha-value>)",
          foreground: "oklch(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "oklch(var(--destructive) / <alpha-value>)",
          foreground: "oklch(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "oklch(var(--muted) / <alpha-value>)",
          foreground: "oklch(var(--muted-foreground) / <alpha-value>)",
        },
        accent: {
          DEFAULT: "oklch(var(--accent) / <alpha-value>)",
          foreground: "oklch(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "oklch(var(--popover))",
          foreground: "oklch(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "oklch(var(--card))",
          foreground: "oklch(var(--card-foreground))",
        },
        chart: {
          1: "oklch(var(--chart-1))",
          2: "oklch(var(--chart-2))",
          3: "oklch(var(--chart-3))",
          4: "oklch(var(--chart-4))",
          5: "oklch(var(--chart-5))",
        },
        sidebar: {
          DEFAULT: "oklch(var(--sidebar))",
          foreground: "oklch(var(--sidebar-foreground))",
          primary: "oklch(var(--sidebar-primary))",
          "primary-foreground": "oklch(var(--sidebar-primary-foreground))",
          accent: "oklch(var(--sidebar-accent))",
          "accent-foreground": "oklch(var(--sidebar-accent-foreground))",
          border: "oklch(var(--sidebar-border))",
          ring: "oklch(var(--sidebar-ring))",
        },
        lime: "oklch(var(--lime))",
        "lime-bright": "oklch(var(--lime-bright))",
        "lime-dark": "oklch(var(--lime-dark))",
        energy: "oklch(var(--energy))",
        "energy-bright": "oklch(var(--energy-bright))",
        surface: "oklch(var(--surface))",
        "surface-raised": "oklch(var(--surface-raised))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        xl: "1rem",
        "2xl": "1.25rem",
        "3xl": "1.75rem",
        "4xl": "2rem",
      },
      boxShadow: {
        xs: "0 1px 2px 0 oklch(0 0 0 / 0.06)",
        sm: "0 1px 3px 0 oklch(0 0 0 / 0.08), 0 1px 2px -1px oklch(0 0 0 / 0.08)",
        md: "0 4px 8px -2px oklch(0 0 0 / 0.1), 0 2px 4px -2px oklch(0 0 0 / 0.06)",
        lg: "0 12px 24px -4px oklch(0 0 0 / 0.12), 0 4px 8px -2px oklch(0 0 0 / 0.08)",
        xl: "0 20px 40px -8px oklch(0 0 0 / 0.16), 0 8px 16px -4px oklch(0 0 0 / 0.1)",
        "lime-sm": "0 2px 12px oklch(0.83 0.24 130 / 0.28), 0 0 0 1px oklch(0.83 0.24 130 / 0.1)",
        "lime-md": "0 4px 24px oklch(0.83 0.24 130 / 0.35), 0 0 0 1px oklch(0.83 0.24 130 / 0.15)",
        "lime-lg": "0 8px 40px oklch(0.83 0.24 130 / 0.4), 0 0 0 1px oklch(0.83 0.24 130 / 0.2)",
        "lime-glow": "0 0 30px oklch(0.83 0.24 130 / 0.5), 0 0 60px oklch(0.83 0.24 130 / 0.2)",
        "energy-sm": "0 2px 12px oklch(0.72 0.25 26 / 0.28)",
        "energy-md": "0 4px 24px oklch(0.72 0.25 26 / 0.35)",
        "inner-lime": "inset 0 1px 0 oklch(0.83 0.24 130 / 0.15)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "pulse-lime": {
          "0%, 100%": { boxShadow: "0 0 0 0 oklch(0.83 0.24 130 / 0.4)" },
          "50%": { boxShadow: "0 0 0 14px oklch(0.83 0.24 130 / 0)" },
        },
        "float": {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" },
        },
        "slide-up": {
          from: { opacity: "0", transform: "translateY(20px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "shimmer": {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "scan-line": {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100vh)" },
        },
        "number-up": {
          from: { opacity: "0", transform: "translateY(12px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-lime": "pulse-lime 2.5s ease-in-out infinite",
        "float": "float 3.5s ease-in-out infinite",
        "slide-up": "slide-up 0.45s cubic-bezier(0.16, 1, 0.3, 1)",
        "fade-in": "fade-in 0.3s ease-out",
        "shimmer": "shimmer 2s linear infinite",
        "number-up": "number-up 0.4s cubic-bezier(0.16, 1, 0.3, 1) both",
      },
    },
  },
  plugins: [typography, containerQueries, animate],
};
