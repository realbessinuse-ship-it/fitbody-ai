import List "mo:core/List";
import Map "mo:core/Map";
import Array "mo:core/Array";
import Text "mo:core/Text";
import Time "mo:core/Time";
import Nat "mo:core/Nat";
import Runtime "mo:core/Runtime";
import Principal "mo:core/Principal";
import MixinAuthorization "authorization/MixinAuthorization";
import AccessControl "authorization/access-control";

actor {
  type NutritionData = {
    foodName : Text;
    calories : Nat;
    date : Time.Time;
  };

  type UserProfile = {
    age : Nat;
    height : Nat;
    weight : Nat;
    gender : Text;
    activityLevel : Text;
    fitnessGoal : Text;
  };

  type DietPlan = {
    goalType : Text;
    dietPreference : Text;
    meals : [MealData];
  };

  type MealData = {
    mealType : Text;
    foods : [FoodItem];
  };

  type FoodItem = {
    name : Text;
    calories : Nat;
  };

  type WorkoutPlan = {
    id : Nat;
    name : Text;
    category : Text;
    difficulty : Text;
    weeklySchedule : [Text];
  };

  type BlogPost = {
    id : Nat;
    title : Text;
    body : Text;
    category : Text;
    author : Text;
    publishedDate : Time.Time;
  };

  // Persistent storage
  let userProfiles = Map.empty<Principal, UserProfile>();
  let nutritionData = Map.empty<Principal, List.List<NutritionData>>();
  let dietPlans = Map.empty<Principal, DietPlan>();
  let workoutPlans = Map.empty<Nat, WorkoutPlan>();
  let blogPosts = Map.empty<Nat, BlogPost>();

  // Authorization system
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);

  // User Profile Management
  public shared ({ caller }) func saveCallerUserProfile(profile : UserProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };
    userProfiles.add(caller, profile);
  };

  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can get profiles");
    };
    userProfiles.get(caller);
  };

  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    if (caller != user and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Can only view your own profile");
    };
    userProfiles.get(user);
  };

  // Diet Plan Management
  public shared ({ caller }) func saveDietPlan(plan : DietPlan) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save diet plans");
    };
    dietPlans.add(caller, plan);
  };

  public query ({ caller }) func getCallerDietPlan() : async ?DietPlan {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can get diet plans");
    };
    dietPlans.get(caller);
  };

  // Nutrition Data
  public shared ({ caller }) func logFoodEntry(foodName : Text, calories : Nat, date : Time.Time) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can log food entries");
    };
    let entry : NutritionData = {
      foodName;
      calories;
      date;
    };

    switch (nutritionData.get(caller)) {
      case (null) {
        let newList = List.fromArray<NutritionData>([entry]);
        nutritionData.add(caller, newList);
      };
      case (?existingList) {
        existingList.add(entry);
      };
    };
  };

  public query ({ caller }) func getEntriesByDate(date : Time.Time) : async [NutritionData] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can get their entries");
    };

    switch (nutritionData.get(caller)) {
      case (null) { [] };
      case (?dataList) {
        let todayEntries = dataList.filter(func(entry) { entry.date == date });
        todayEntries.toArray();
      };
    };
  };

  // Workout Plans
  public query ({ caller }) func getAllWorkoutPlans() : async [WorkoutPlan] {
    workoutPlans.values().toArray();
  };

  public query ({ caller }) func getWorkoutPlansByCategory(category : Text) : async [WorkoutPlan] {
    workoutPlans.values().toArray().filter(func(plan) { Text.equal(plan.category, category) });
  };

  public query ({ caller }) func getWorkoutPlansByDifficulty(difficulty : Text) : async [WorkoutPlan] {
    workoutPlans.values().toArray().filter(func(plan) { Text.equal(plan.difficulty, difficulty) });
  };

  // Blog Posts
  public shared ({ caller }) func addBlogPost(title : Text, body : Text, category : Text, author : Text) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can add blog posts");
    };

    let id = blogPosts.size();
    let newPost : BlogPost = {
      id;
      title;
      body;
      category;
      author;
      publishedDate = Time.now();
    };

    blogPosts.add(id, newPost);
  };

  public query ({ caller }) func getAllBlogPosts() : async [BlogPost] {
    blogPosts.values().toArray();
  };

  public query ({ caller }) func getBlogPostsByCategory(category : Text) : async [BlogPost] {
    blogPosts.values().toArray().filter(func(post) { Text.equal(post.category, category) });
  };
};
